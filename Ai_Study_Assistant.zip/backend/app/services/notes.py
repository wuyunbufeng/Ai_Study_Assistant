from starlette.concurrency import run_in_threadpool
from ..models.notes import Note
from .asr import transcribe_audio
from .llm import summarize_transcript


def generate_markdown(note: Note) -> str:
    """
    Convert a Note object into a Markdown-formatted string.
    """
    markdown = []

    if note.lecture_title:
        markdown.append(f"# {note.lecture_title}\n")

    for section in note.sections:
        markdown.append(f"## {section.title}\n")
        if section.key_points:
            markdown.append("### Key Points\n")
            for point in section.key_points:
                markdown.append(f"- {point}\n")
        if section.examples:
            markdown.append("### Examples\n")
            for example in section.examples:
                markdown.append(f"- {example}\n")
        if section.summary:
            markdown.append("### Summary\n")
            markdown.append(f"{section.summary}\n")

    if note.keywords:
        markdown.append("## Keywords\n")
        markdown.append(", ".join(note.keywords) + "\n")

    if note.raw_transcript:
        markdown.append("## Raw Transcript\n")
        markdown.append(note.raw_transcript + "\n")

    return "\n".join(markdown)


async def generate_note_from_audio(file_path: str) -> Note:
    """
    High-level orchestration: transcribe the audio then summarize into a Note.
    """
    # Run the synchronous transcribe_audio in a thread pool
    transcript = await run_in_threadpool(transcribe_audio, file_path)
    note = await summarize_transcript(transcript)
    note.raw_transcript = transcript
    return note
