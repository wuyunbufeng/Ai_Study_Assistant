import json
import logging
import os
import re
from typing import Any, Dict

import dashscope

from ..core.config import get_settings
from ..models.notes import Note, NoteSection


logger = logging.getLogger(__name__)


def build_summarization_prompt(transcript: str) -> str:
    return '''你是一名助教，请将以下课堂录音转录文本整理成结构化笔记。

输出要求：
1. 必须是纯JSON格式，不要有任何额外文本
2. JSON结构如下：
{
  "lecture_title": "课程标题",
  "keywords": ["关键词1", "关键词2", "关键词3"],
  "sections": [
    {
      "title": "小节标题",
      "key_points": ["要点1", "要点2"],
      "examples": ["示例1"],
      "summary": "本节总结"
    }
  ]
}

课堂转录文本：
"""%s"""

请直接输出JSON，不要解释。''' % transcript[:1500]  # 先限制长度测试


def _extract_response_text(response: Any) -> str | None:
    output = getattr(response, "output", None)
    if output is None:
        return None

    if isinstance(output, dict):
        text = output.get("text")
        if text:
            return text
        choices = output.get("choices") or []
    else:
        text = getattr(output, "text", None)
        if text:
            return text
        choices = getattr(output, "choices", None) or []

    if choices:
        first = choices[0]
        if isinstance(first, dict):
            msg = first.get("message")
            if isinstance(msg, dict):
                content = msg.get("content")
                if content:
                    return content
            content = first.get("content") or first.get("text")
            if content:
                return content
        else:
            message = getattr(first, "message", None)
            if message is not None:
                content = getattr(message, "content", None)
                if content:
                    return content
            content = getattr(first, "content", None)
            if content:
                return content
    return None


def get_response(
    prompt: str,
    model: str = "qwen3-max",
    temperature: float = 0.7,
    top_p: float = 0.8,
) -> str:
    settings = get_settings()

    logger.info("API Key loaded: %s", "YES" if settings.DASHSCOPE_API_KEY else "NO")

    messages = [{"role": "user", "content": prompt}]

    try:
        response = dashscope.Generation.call(
            api_key=settings.DASHSCOPE_API_KEY,
            model=model,
            messages=messages,
            top_p=top_p,
            temperature=temperature,
            enable_thinking=False,
            seed=377,
        )

        logger.info("API Status: %s, Message: %s", response.status_code, response.message)

        if response.status_code != 200:
            logger.error("API Error: %s - %s", response.status_code, response.message)
            return "no reply"

        text = _extract_response_text(response)
        if text:
            return text
        logger.error("Unexpected response structure: %s", response)
        return "no reply"

    except Exception as e:
        logger.error("API call failed: %s", e)
        return "no reply"
def save_transcript_to_file(transcript: str, file_path: str) -> None:
    """
    Save the raw transcript to a plain text file.
    """
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(transcript)


def save_markdown_to_file(markdown_content: str, file_path: str) -> None:
    """
    Save the formatted markdown content to a file.
    """
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(markdown_content)


async def summarize_transcript(transcript: str) -> Note:
    """
    Use Qwen API to summarize the transcript into a Note structure and save outputs.
    """
    prompt = build_summarization_prompt(transcript)
    try:
        response = get_response(prompt)
        
        # 添加调试：查看API返回的原始响应
        logger.info("Raw API response: %s", response[:500] if response else "Empty")
        if response == "no reply":
            raise ValueError("Qwen API returned no valid response.")
        # 尝试解析JSON
        data = json.loads(response)
    except json.JSONDecodeError as json_err:
        logger.error("JSON解析失败！API返回的内容是：%s", response)
        logger.error("JSON错误详情：%s", json_err)
        logger.warning("Failed to decode Qwen response, using fallback. reason=%s", json_err)
        # Fallback with simple stub data for local development
        data = {
            "lecture_title": "Sample Lecture",
            "keywords": ["placeholder", "note", "demo"],
            "sections": [
                {
                    "title": "Introduction",
                    "key_points": [
                        "No LLM key provided; showing mock notes",
                        "Replace with real Qwen API key to enable summarization",
                    ],
                    "examples": ["Example concept from transcript"],
                    "summary": "Mock summary generated locally.",
                }
            ],
        }
    except Exception as exc:
        logger.warning("Qwen summarization unavailable, using fallback. reason=%s", exc)
        data = {
            "lecture_title": "Sample Lecture",
            "keywords": ["placeholder", "note", "demo"],
            "sections": [
                {
                    "title": "Introduction",
                    "key_points": [
                        "No LLM key provided; showing mock notes",
                        "Replace with real Qwen API key to enable summarization",
                    ],
                    "examples": ["Example concept from transcript"],
                    "summary": "Mock summary generated locally.",
                }
            ],
        }

    sections = [
        NoteSection(
            title=item.get("title", "Untitled Section"),
            key_points=item.get("key_points", []),
            examples=item.get("examples"),
            summary=item.get("summary"),
        )
        for item in data.get("sections", [])
    ]
    note = Note(
        lecture_title=data.get("lecture_title"),
        sections=sections,
        keywords=data.get("keywords"),
    )

    # Save raw transcript and markdown note to files
    transcript_file_path = os.path.join("data", "transcript.txt")
    markdown_file_path = os.path.join("data", "notes.md")

    save_transcript_to_file(transcript, transcript_file_path)
    save_markdown_to_file(note.to_markdown(), markdown_file_path)

    return note


ANALYSIS_INPUT_LIMIT = 3500
METADATA_INPUT_LIMIT = 1200


def build_error_analysis_prompt(
    structured_text: str,
    subject: str | None = None,
    knowledge_point: str | None = None,
    note: str | None = None,
) -> str:
    question_text = (structured_text or "").strip()
    if not question_text:
        question_text = "N/A"
    else:
        question_text = question_text[:ANALYSIS_INPUT_LIMIT]

    return (
        "你是有经验的学科老师，请根据下方题干给出简短分析，Short Conclusion部分要包含该题的答案，不超过100字。\n"
        "不要指出题目或OCR文本的错误，不要评论识别质量。\n"
        "若信息不完整，直接按最合理理解继续分析，不要特别说明假设来源。\n"
        "保留题干中的公式格式（如 $$...$$）。\n"
        "输出为中文 Markdown，且仅包含两个小节：\n"
        "## Short Conclusion\n"
        "## Step-by-step Reasoning\n\n"
        f"Subject: {subject or 'unknown'}\n"
        f"Knowledge Point: {knowledge_point or 'unknown'}\n"
        f"Student Note: {note or 'none'}\n"
        "Question Text:\n"
        f"{question_text}\n"
    )


def build_error_metadata_prompt(question_text: str) -> str:
    cleaned = (question_text or "").strip()
    if cleaned:
        cleaned = cleaned[:METADATA_INPUT_LIMIT]
    else:
        cleaned = "N/A"

    return (
        "Extract the subject and the most relevant knowledge point from the question text.\n"
        "Return JSON only, no extra text. Use empty strings if unknown.\n"
        "Use Simplified Chinese terms for both subject and knowledge_point, even if the question is in English.\n"
        'Schema: {"subject": "...", "knowledge_point": "..."}\n'
        "Question Text:\n"
        f"{cleaned}\n"
    )


def _load_json_response(response: str) -> Dict[str, Any]:
    try:
        return json.loads(response)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", response, re.DOTALL)
        if match:
            return json.loads(match.group(0))
    raise ValueError("Failed to parse JSON response from LLM.")


def extract_error_metadata(
    question_text: str,
    model: str | None = None,
) -> Dict[str, str]:
    if not question_text.strip():
        return {"subject": "", "knowledge_point": ""}

    settings = get_settings()
    prompt = build_error_metadata_prompt(question_text)
    response = get_response(
        prompt,
        model=model or settings.llm_model_name,
        temperature=0.2,
        top_p=0.8,
    )
    if not response or response == "no reply":
        raise ValueError("LLM returned no metadata response.")

    data = _load_json_response(response)
    subject = str(data.get("subject", "") or "").strip()
    knowledge_point = str(data.get("knowledge_point", "") or "").strip()
    return {"subject": subject, "knowledge_point": knowledge_point}


def analyze_wrong_question(
    structured_text: str,
    subject: str | None = None,
    knowledge_point: str | None = None,
    note: str | None = None,
    model: str | None = None,
) -> str:
    settings = get_settings()
    prompt = build_error_analysis_prompt(structured_text, subject, knowledge_point, note)
    response = get_response(
        prompt,
        model=model or settings.llm_model_name,
        temperature=0.3,
        top_p=0.8,
    )
    if not response or response == "no reply":
        raise ValueError("LLM returned no analysis response.")
    return response.strip()
