import os
from typing import Any, List, Optional, TypedDict

try:
    from paddleocr import PPStructureV3  # type: ignore
except ImportError:
    PPStructureV3 = None  # type: ignore

# Cache engine
_structure_engine: Optional["PPStructureV3"] = None

# Cache/download location to avoid repeated downloads and permission issues
os.environ.setdefault(
    "PADDLEOCR_HOME", os.path.join(os.getcwd(), "data", "paddle_ocr_cache")
)

MAX_SIDE_LIMIT = 4000  # allow higher resolution for formula recognition
FORMULA_DET_THRESH = 0.10


class FormulaRegion(TypedDict):
    latex: str
    box: Any
    score: Optional[float]


def _get_engine() -> "PPStructureV3":
    global _structure_engine  # noqa: PLW0603
    if _structure_engine is None:
        if PPStructureV3 is None:
            raise RuntimeError(
                "PPStructureV3 is not installed. Please install paddlepaddle and paddleocr per your platform."
            )
        _structure_engine = PPStructureV3(
            use_formula_recognition=True,
            use_table_recognition=False,
            use_chart_recognition=False,
            use_seal_recognition=False,
            use_region_detection=True,
            lang="ch",
            ocr_version="PP-OCRv5",
        )
    return _structure_engine


def run_structure_ocr(image_input: Any) -> List[Any]:
    engine = _get_engine()
    return engine.predict(
        image_input,
        use_formula_recognition=True,
        use_table_recognition=False,
        use_chart_recognition=False,
        use_seal_recognition=False,
        use_region_detection=True,
        layout_threshold={7: FORMULA_DET_THRESH},
        text_det_limit_side_len=MAX_SIDE_LIMIT,
        text_det_limit_type="max",
    )


def _get_attr(item: Any, keys: List[str]) -> Any:
    for key in keys:
        if isinstance(item, dict) and key in item:
            return item.get(key)
        if hasattr(item, key):
            return getattr(item, key)
    return None


def _is_formula_type(type_value: Any) -> bool:
    if not type_value:
        return False
    type_str = str(type_value).lower()
    return any(token in type_str for token in ("formula", "equation", "math"))


def _extract_formula_from_res(res: Any) -> tuple[Optional[str], Optional[float]]:
    if isinstance(res, dict):
        text = res.get("latex") or res.get("text")
        score = res.get("score") or res.get("rec_score")
        return (str(text) if text else None, score)
    if isinstance(res, list):
        for item in res:
            if isinstance(item, dict):
                text = item.get("latex") or item.get("text")
                if text:
                    score = item.get("score") or item.get("rec_score")
                    return (str(text), score)
            elif isinstance(item, str) and item.strip():
                return (item.strip(), None)
    if isinstance(res, str) and res.strip():
        return (res.strip(), None)
    return (None, None)


def extract_formula_regions(results: List[Any]) -> List[FormulaRegion]:
    regions: List[FormulaRegion] = []
    for result in results or []:
        res = _get_attr(result, ["res", "result"])
        latex, score = _extract_formula_from_res(res)
        type_value = _get_attr(result, ["type", "type_name", "label", "cls"])
        if not latex and not _is_formula_type(type_value):
            continue
        if not latex:
            continue
        box = _get_attr(result, ["bbox", "box", "rect", "points"])
        if isinstance(result, dict) and not box:
            region = result.get("region") if isinstance(result.get("region"), dict) else None
            if region:
                box = region.get("bbox") or region.get("box")
        regions.append(
            {
                "latex": latex,
                "box": box,
                "score": score,
            }
        )
    return regions


def extract_structured_text(image_path: str) -> str:
    """
    Use PP-StructureV3 to extract structured text with LaTeX formulas.
    Returns a markdown-like string with formulas wrapped in $$...$$.
    """
    results = run_structure_ocr(image_path)
    if not results:
        return ""

    markdown_list = []
    for result in results:
        try:
            markdown_list.append(result._to_markdown(pretty=False))
        except Exception:
            continue

    if not markdown_list:
        return ""

    if len(markdown_list) == 1:
        return markdown_list[0].get("markdown_texts", "")

    return engine.concatenate_markdown_pages(markdown_list)
