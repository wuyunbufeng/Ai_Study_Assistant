import os
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple, TypedDict

import numpy as np
from PIL import Image

try:
    from paddleocr import PaddleOCR  # type: ignore
except ImportError:
    PaddleOCR = None  # type: ignore

# Cache engines by language
_ocr_engines: Dict[str, "PaddleOCR"] = {}

# Cache/download location to avoid repeated downloads and permission issues
os.environ.setdefault(
    "PADDLEOCR_HOME", os.path.join(os.getcwd(), "data", "paddle_ocr_cache")
)

MAX_SIDE_LIMIT = 3200  # downscale oversized images to avoid Paddle limit (~4000)
LANG_DETECT_MAX_SIDE = 960
LANG_CJK = "ch"
LANG_EN = "en"
CJK_RE = re.compile(r"[\u4e00-\u9fff]")
LATIN_RE = re.compile(r"[A-Za-z]")


class OcrLine(TypedDict):
    text: str
    box: Optional[Sequence[Sequence[float]] | Sequence[float]]
    score: Optional[float]


def _build_engine_params(lang: str) -> Dict[str, Any]:
    return {
        "use_angle_cls": True,
        "lang": lang,
        "ocr_version": "PP-OCRv5",
        "det_db_thresh": 0.20,
        "det_db_box_thresh": 0.35,
        "det_db_unclip_ratio": 1.8,
        "text_rec_score_thresh": 0.25,
    }


def _get_engine(lang: str) -> "PaddleOCR":
    global _ocr_engines  # noqa: PLW0603
    if PaddleOCR is None:
        raise RuntimeError(
            "PaddleOCR is not installed. Please install paddlepaddle and paddleocr per your platform."
        )
    if lang not in _ocr_engines:
        params = _build_engine_params(lang)
        try:
            _ocr_engines[lang] = PaddleOCR(**params)
        except ValueError as exc:
            if "Unknown argument" in str(exc):
                params.pop("text_rec_score_thresh", None)
                params["drop_score"] = 0.25
                _ocr_engines[lang] = PaddleOCR(**params)
            else:
                raise
    return _ocr_engines[lang]


def load_image_array(image_path: str) -> np.ndarray:
    img = Image.open(image_path).convert("RGB")
    w, h = img.size
    max_side = max(w, h)
    if max_side > MAX_SIDE_LIMIT:
        scale = MAX_SIDE_LIMIT / max_side
        new_size = (int(w * scale), int(h * scale))
        img = img.resize(new_size, Image.LANCZOS)
    return np.array(img)


def _downscale_for_lang_detect(image_array: np.ndarray) -> np.ndarray:
    h, w = image_array.shape[:2]
    max_side = max(w, h)
    if max_side <= LANG_DETECT_MAX_SIDE:
        return image_array
    scale = LANG_DETECT_MAX_SIDE / max_side
    new_size = (int(w * scale), int(h * scale))
    img = Image.fromarray(image_array)
    img = img.resize(new_size, Image.BILINEAR)
    return np.array(img)


def _safe_get_list_item(items: Any, index: int) -> Any:
    if items is None:
        return None
    if isinstance(items, (list, tuple, np.ndarray)) and index < len(items):
        return items[index]
    return None


def _pick_first(*candidates: Any) -> Any:
    for item in candidates:
        if item is None:
            continue
        if isinstance(item, np.ndarray):
            if item.size == 0:
                continue
            return item
        if isinstance(item, (list, tuple, dict)):
            if len(item) == 0:
                continue
            return item
        return item
    return None


def _extract_lines_from_dict(item: dict) -> List[OcrLine]:
    lines: List[OcrLine] = []
    rec_texts = item.get("rec_texts")
    if isinstance(rec_texts, np.ndarray):
        rec_texts = rec_texts.tolist()
    rec_scores = item.get("rec_scores")
    rec_boxes = _pick_first(item.get("rec_boxes"), item.get("det_boxes"), item.get("boxes"))

    if isinstance(rec_texts, list):
        for idx, text in enumerate(rec_texts):
            if not text:
                continue
            lines.append(
                {
                    "text": str(text),
                    "box": _safe_get_list_item(rec_boxes, idx),
                    "score": _safe_get_list_item(rec_scores, idx),
                }
            )
        return lines

    res = item.get("res")
    if isinstance(res, list):
        for rec in res:
            if not isinstance(rec, dict):
                continue
            text = rec.get("text") or rec.get("rec_text")
            if not text:
                continue
            lines.append(
                {
                    "text": str(text),
                    "box": rec.get("box") or rec.get("bbox") or rec.get("points"),
                    "score": rec.get("score") or rec.get("rec_score"),
                }
            )
    return lines


def _extract_lines_from_result(result: Any) -> List[OcrLine]:
    lines: List[OcrLine] = []
    if not result:
        return lines

    if isinstance(result, dict):
        result_list = [result]
    else:
        result_list = result

    first = result_list[0] if isinstance(result_list, list) and result_list else None
    if isinstance(first, dict):
        for item in result_list:
            if isinstance(item, dict):
                lines.extend(_extract_lines_from_dict(item))
        return lines

    # Legacy format: list of [bbox, (text, score)]
    if isinstance(result_list, list):
        for line in result_list:
            if (
                line
                and isinstance(line, list)
                and len(line) > 1
                and isinstance(line[1], (list, tuple))
                and len(line[1]) > 0
            ):
                text = line[1][0]
                if text:
                    lines.append(
                        {
                            "text": str(text),
                            "box": line[0],
                            "score": line[1][1] if len(line[1]) > 1 else None,
                        }
                    )

    return lines


def _ocr_lines_with_lang(image_array: np.ndarray, lang: str) -> List[OcrLine]:
    engine = _get_engine(lang)
    result = engine.ocr(image_array)
    return _extract_lines_from_result(result)


def _language_stats(lines: List[OcrLine]) -> Tuple[int, int, float, int]:
    text = "".join([line["text"] for line in lines if line.get("text")])
    cjk_count = len(CJK_RE.findall(text))
    latin_count = len(LATIN_RE.findall(text))
    score_sum = 0.0
    score_count = 0
    for line in lines:
        score = line.get("score")
        if score is None:
            continue
        try:
            score_sum += float(score)
            score_count += 1
        except (TypeError, ValueError):
            continue
    avg_score = score_sum / score_count if score_count else 0.0
    total_chars = cjk_count + latin_count
    return cjk_count, latin_count, avg_score, total_chars


def _lang_quality(avg_score: float, total_chars: int) -> float:
    return avg_score + min(total_chars, 40) * 0.01


def _detect_ocr_language(image_array: np.ndarray) -> str:
    sample = _downscale_for_lang_detect(image_array)
    ch_lines = _ocr_lines_with_lang(sample, LANG_CJK)
    ch_cjk, ch_latin, ch_score, ch_total = _language_stats(ch_lines)
    # Force Chinese model if any CJK is detected in the image.
    if ch_cjk > 0:
        return LANG_CJK

    en_lines = _ocr_lines_with_lang(sample, LANG_EN)
    en_cjk, en_latin, en_score, en_total = _language_stats(en_lines)
    if en_cjk > 0:
        return LANG_CJK
    if en_latin >= 4 and en_latin >= en_cjk * 2:
        return LANG_EN

    ch_quality = _lang_quality(ch_score, ch_total)
    en_quality = _lang_quality(en_score, en_total)
    return LANG_EN if en_quality > ch_quality else LANG_CJK


def ocr_image_lines(
    image_path: str,
    image_array: Optional[np.ndarray] = None,
    lang: Optional[str] = None,
) -> List[OcrLine]:
    img_array = image_array if image_array is not None else load_image_array(image_path)
    selected_lang = lang or _detect_ocr_language(img_array)
    return _ocr_lines_with_lang(img_array, selected_lang)


def lines_to_text(lines: List[OcrLine]) -> str:
    return "\n".join([line["text"] for line in lines if line.get("text")])


def ocr_image(image_path: str, lang: Optional[str] = None) -> str:
    """
    Use PaddleOCR to extract text from the given image path.
    Returns a newline-joined string of detected text lines.
    """
    return lines_to_text(ocr_image_lines(image_path, lang=lang))

    # PaddleOCR >= 3.3 returns a list of dicts with `rec_texts`.
    # Older versions return a nested list of [bbox, (text, score)].
    lines: List[str] = []
    if not result:
        return ""

    first = result[0]
    if isinstance(first, dict):
        # New format
        for item in result:
            if not isinstance(item, dict):
                continue
            if isinstance(item.get("rec_texts"), list):
                lines.extend([str(t) for t in item["rec_texts"] if t])
            # Some builds put recognition results under "res"
            if isinstance(item.get("res"), list):
                for rec in item["res"]:
                    if isinstance(rec, dict) and rec.get("text"):
                        lines.append(str(rec["text"]))
    else:
        # Legacy format
        for line in result:
            if (
                line
                and isinstance(line, list)
                and len(line) > 1
                and isinstance(line[1], (list, tuple))
                and len(line[1]) > 0
            ):
                text = line[1][0]
                if text:
                    lines.append(str(text))

    return "\n".join(lines)
