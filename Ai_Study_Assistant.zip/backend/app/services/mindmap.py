import uuid
from typing import List, Optional
from ..models.mindmap import MindMap, MindMapNode
from ..models.notes import Note, NoteSection


def note_to_mindmap(note: Note) -> MindMap:
    """
    Convert a Note object to a MindMap object.
    """
    nodes: List[MindMapNode] = []
    
    # Create root node with lecture title
    root_id = str(uuid.uuid4())
    root_text = note.lecture_title or "Untitled Lecture"
    root_node = MindMapNode(id=root_id, text=root_text)
    nodes.append(root_node)
    
    # Add keywords as direct children of root (if any)
    if note.keywords:
        keywords_id = str(uuid.uuid4())
        keywords_node = MindMapNode(id=keywords_id, text="关键词", parent_id=root_id)
        nodes.append(keywords_node)
        
        for keyword in note.keywords:
            keyword_id = str(uuid.uuid4())
            keyword_node = MindMapNode(id=keyword_id, text=keyword, parent_id=keywords_id)
            nodes.append(keyword_node)
    
    # Add sections as children of root
    for section in note.sections:
        section_id = str(uuid.uuid4())
        section_node = MindMapNode(id=section_id, text=section.title, parent_id=root_id)
        nodes.append(section_node)
        
        # Add key points as children of section
        if section.key_points:
            key_points_id = str(uuid.uuid4())
            key_points_node = MindMapNode(id=key_points_id, text="要点", parent_id=section_id)
            nodes.append(key_points_node)
            
            for point in section.key_points:
                point_id = str(uuid.uuid4())
                point_node = MindMapNode(id=point_id, text=point, parent_id=key_points_id)
                nodes.append(point_node)
        
        # Add examples as children of section
        if section.examples:
            examples_id = str(uuid.uuid4())
            examples_node = MindMapNode(id=examples_id, text="示例", parent_id=section_id)
            nodes.append(examples_node)
            
            for example in section.examples:
                example_id = str(uuid.uuid4())
                example_node = MindMapNode(id=example_id, text=example, parent_id=examples_id)
                nodes.append(example_node)
        
        # Add summary as child of section
        if section.summary:
            summary_id = str(uuid.uuid4())
            summary_node = MindMapNode(id=summary_id, text="总结", parent_id=section_id)
            nodes.append(summary_node)
            
            summary_content_id = str(uuid.uuid4())
            summary_content_node = MindMapNode(id=summary_content_id, text=section.summary, parent_id=summary_id)
            nodes.append(summary_content_node)
    
    return MindMap(title=note.lecture_title, nodes=nodes)


def mindmap_to_mermaid(mindmap: MindMap) -> str:
    """
    Convert a MindMap object to Mermaid.js flowchart syntax.
    """
    lines = ["graph TB", ""]
    
    for node in mindmap.nodes:
        # Escape special characters for Mermaid
        escaped_text = node.text.replace("\n", "\\n").replace('"', '\\"')
        
        # Add node definition
        lines.append(f'    {node.id}["{escaped_text}"]')
        
    # Build ordered child lists to force vertical layout (chain siblings invisibly)
    children_by_parent: dict[str, List[MindMapNode]] = {}
    for node in mindmap.nodes:
        if node.parent_id:
            children_by_parent.setdefault(node.parent_id, []).append(node)

    hidden_links: List[int] = []
    link_index = 0
    for parent_id, children in children_by_parent.items():
        if not children:
            continue
        for child in children:
            lines.append(f"    {parent_id} --> {child.id}")
            link_index += 1
        for prev_node, next_node in zip(children, children[1:]):
            lines.append(f"    {prev_node.id} --> {next_node.id}")
            hidden_links.append(link_index)
            link_index += 1

    if hidden_links:
        indices = ",".join(str(index) for index in hidden_links)
        lines.append(f"    linkStyle {indices} stroke:transparent,stroke-width:0px;")
    
    return "\n".join(lines)


def note_to_mermaid(note: Note) -> str:
    """
    Convert a Note object directly to Mermaid.js flowchart syntax.
    """
    mindmap = note_to_mindmap(note)
    return mindmap_to_mermaid(mindmap)


def markdown_to_mindmap(markdown: str) -> MindMap:
    """
    Convert Markdown text to a MindMap object.
    This is a basic implementation that parses headers and lists.
    """
    nodes: List[MindMapNode] = []
    
    # Create root node with default title
    root_id = str(uuid.uuid4())
    root_node = MindMapNode(id=root_id, text="Untitled Mind Map")
    nodes.append(root_node)
    
    # Stack to keep track of parent nodes by header level
    header_stack = [(1, root_id)]  # (level, node_id)
    current_list_parent = None
    
    # Parse markdown line by line
    for line in markdown.splitlines():
        line = line.strip()
        if not line:
            continue
        
        # Check for headers
        if line.startswith('#'):
            # Calculate header level
            level = len(line.split()[0])
            text = line[level:].strip()
            
            # Create new node
            node_id = str(uuid.uuid4())
            node = MindMapNode(id=node_id, text=text)
            nodes.append(node)
            
            # Find parent node (the closest ancestor with lower level)
            while header_stack and header_stack[-1][0] >= level:
                header_stack.pop()
            
            if header_stack:
                node.parent_id = header_stack[-1][1]
            
            # Update header stack
            header_stack.append((level, node_id))
            current_list_parent = None
        
        # Check for list items
        elif line.startswith('- ') or line.startswith('* '):
            text = line[2:].strip()
            
            # Create new node
            node_id = str(uuid.uuid4())
            node = MindMapNode(id=node_id, text=text)
            nodes.append(node)
            
            # Determine parent node for list item
            if current_list_parent:
                # Continue adding to the same parent
                node.parent_id = current_list_parent
            else:
                # Add to the current header
                if header_stack:
                    node.parent_id = header_stack[-1][1]
                    # Set this as the parent for subsequent list items
                    current_list_parent = header_stack[-1][1]
        
        # Check for bold text (potential keywords)
        elif line.startswith('**') and '**:' in line:
            text = line.split('**:', 1)[1].strip()
            items = [item.strip() for item in text.split(',')]
            
            # Create keywords node
            keywords_id = str(uuid.uuid4())
            keywords_node = MindMapNode(id=keywords_id, text="关键词")
            nodes.append(keywords_node)
            
            # Find parent node (current header)
            if header_stack:
                keywords_node.parent_id = header_stack[-1][1]
            
            # Add individual keywords
            for item in items:
                if item:
                    keyword_id = str(uuid.uuid4())
                    keyword_node = MindMapNode(id=keyword_id, text=item, parent_id=keywords_id)
                    nodes.append(keyword_node)
            
            current_list_parent = None
    
    # If we have a root node with children, use the first child's text as the mind map title
    if len(nodes) > 1:
        first_child = next((node for node in nodes if node.parent_id == root_id), None)
        if first_child:
            root_node.text = first_child.text
            nodes = [root_node] + [node for node in nodes if node.id != first_child.id]
    
    return MindMap(title=root_node.text, nodes=nodes)


def markdown_to_mermaid(markdown: str) -> str:
    """
    Convert Markdown text directly to Mermaid.js flowchart syntax.
    """
    mindmap = markdown_to_mindmap(markdown)
    return mindmap_to_mermaid(mindmap)
