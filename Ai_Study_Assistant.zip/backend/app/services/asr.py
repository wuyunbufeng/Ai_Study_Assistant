import logging
import os
import re
import shutil
from pathlib import Path
from typing import Optional

import jieba
import jieba.posseg as pseg
import whisper

logger = logging.getLogger(__name__)


def _ensure_ffmpeg() -> None:
    ffmpeg_bin = os.environ.get("FFMPEG_BIN")
    if ffmpeg_bin:
        ffmpeg_path = Path(ffmpeg_bin)
        if ffmpeg_path.is_file():
            os.environ["PATH"] = (
                str(ffmpeg_path.parent) + os.pathsep + os.environ.get("PATH", "")
            )
            return
        if ffmpeg_path.is_dir():
            os.environ["PATH"] = str(ffmpeg_path) + os.pathsep + os.environ.get(
                "PATH", ""
            )
            return

    if shutil.which("ffmpeg"):
        return

    project_root = Path(__file__).resolve().parents[2]
    candidates = [
        project_root / "ffmpeg" / "bin" / "ffmpeg.exe",
        project_root / "ffmpeg" / "ffmpeg.exe",
        project_root / "ffmpeg" / "ffmpeg",
    ]
    for candidate in candidates:
        if candidate.exists():
            os.environ["PATH"] = (
                str(candidate.parent) + os.pathsep + os.environ.get("PATH", "")
            )
            return

    raise RuntimeError(
        "ffmpeg not found. Install ffmpeg or set FFMPEG_BIN to the ffmpeg binary "
        "or its folder."
    )


def _is_likely_english(text: str) -> bool:
    cjk_count = len(re.findall(r"[\u4e00-\u9fff]", text))
    latin_count = len(re.findall(r"[A-Za-z]", text))
    if latin_count == 0:
        return False
    if cjk_count == 0:
        return True
    return latin_count >= cjk_count * 3 and cjk_count < 10


def _light_cleanup_english(text: str) -> str:
    cleaned = (
        text.replace("，", ",")
        .replace("。", ".")
        .replace("？", "?")
        .replace("！", "!")
        .replace("：", ":")
        .replace("；", ";")
        .replace("（", "(")
        .replace("）", ")")
        .replace("“", '"')
        .replace("”", '"')
        .replace("’", "'")
    )
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    cleaned = re.sub(r"(?:\s*,){2,}", ",", cleaned)
    cleaned = re.sub(r"\s+([,.;:?!])", r"\1", cleaned)
    cleaned = re.sub(r"([,.;:?!])[ \t]+", r"\1 ", cleaned)
    cleaned = re.sub(r"([,.;:?!])([A-Za-z0-9])", r"\1 \2", cleaned)
    cleaned = re.sub(r"\s+'", "'", cleaned)
    cleaned = re.sub(r"'\s+", "'", cleaned)
    cleaned = re.sub(r"\s+([)\]])", r"\1", cleaned)
    cleaned = re.sub(r"([(\[])\s+", r"\1", cleaned)
    return cleaned.strip()


def post_process_transcript(transcript: str) -> str:
    """
    Post-process the transcript to add punctuation and correct common homophones.
    """
    transcript = transcript.strip()
    if not transcript:
        return transcript
    if _is_likely_english(transcript):
        return _light_cleanup_english(transcript)

    # Common homophone corrections
    corrections = {
        "危机分": "微积分",
        "韩术": "函数",
        "集线": "极限",
        "描述法": "描述法",
    }

    # Replace common homophones
    for incorrect, correct in corrections.items():
        transcript = transcript.replace(incorrect, correct)

    # Add basic punctuation (naive approach)
    words = pseg.cut(transcript)
    processed = []
    for word, flag in words:
        processed.append(word)
        if flag in {"x", "uj", "ul"}:  # Add punctuation after certain words
            processed.append("，")
    transcript = "".join(processed)

    # Ensure proper sentence-ending punctuation
    if not transcript.endswith("。"):
        transcript += "。"

    return transcript


def transcribe_audio(file_path: str) -> str:
    """
    Transcribe an audio file into text using a locally deployed Whisper model.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {file_path}")

    _ensure_ffmpeg()

    try:
        # Load the Whisper model (base model for local deployment)
        model = whisper.load_model("base")
        result = model.transcribe(str(path))
        transcript: Optional[str] = result.get("text", "").strip()

        if not transcript:
            raise RuntimeError("Whisper transcription returned an empty result.")

        # Post-process the transcript to correct homophones and add punctuation
        transcript = post_process_transcript(transcript)

        return transcript
    except Exception as exc:
        logger.exception("Failed to transcribe audio using local Whisper model: %s", exc)
        raise RuntimeError("Local Whisper transcription failed") from exc
