import re
from typing import Any, Dict, List, Optional, Tuple

from .ocr import OcrLine, load_image_array, lines_to_text, ocr_image_lines
from .structure_ocr import extract_formula_regions, run_structure_ocr

FORMULA_OVERLAP_THRESHOLD = 0.35
FORMULA_MIN_SCORE = 0.4
INLINE_MATH_RE = re.compile(r"[A-Za-z0-9=+\-*/^_{}()<>≤≥.,]+")
CJK_RE = re.compile(r"[\u4e00-\u9fff]")
FORMULA_MIN_LEN = 2
FORMULA_TOKEN_RE = re.compile(r"(\\[a-zA-Z]+|[=+\-*/^_])")


def _strip_formula_wrappers(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("$$") and stripped.endswith("$$"):
        return stripped[2:-2].strip()
    if stripped.startswith("$") and stripped.endswith("$"):
        return stripped[1:-1].strip()
    return stripped


def _wrap_formula(text: str) -> str:
    inner = _strip_formula_wrappers(text)
    return f"$${inner}$$"


def _wrap_inline_formula(text: str) -> str:
    inner = _strip_formula_wrappers(text)
    return f"${inner}$"


def _normalize_box(box: Any) -> Optional[Tuple[float, float, float, float]]:
    if not box:
        return None
    if isinstance(box, dict):
        x1 = box.get("x1")
        y1 = box.get("y1")
        x2 = box.get("x2")
        y2 = box.get("y2")
        if None not in (x1, y1, x2, y2):
            return (float(x1), float(y1), float(x2), float(y2))
    if isinstance(box, (list, tuple)):
        if len(box) == 4 and all(isinstance(v, (int, float)) for v in box):
            x1, y1, x2, y2 = [float(v) for v in box]
            return (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
        if len(box) == 8 and all(isinstance(v, (int, float)) for v in box):
            xs = [float(v) for v in box[::2]]
            ys = [float(v) for v in box[1::2]]
            return (min(xs), min(ys), max(xs), max(ys))
        if len(box) == 4 and all(isinstance(v, (list, tuple)) for v in box):
            xs = [float(pt[0]) for pt in box if len(pt) >= 2]
            ys = [float(pt[1]) for pt in box if len(pt) >= 2]
            if xs and ys:
                return (min(xs), min(ys), max(xs), max(ys))
    return None


def _overlap_ratio(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float]) -> float:
    x_left = max(a[0], b[0])
    y_top = max(a[1], b[1])
    x_right = min(a[2], b[2])
    y_bottom = min(a[3], b[3])
    if x_right <= x_left or y_bottom <= y_top:
        return 0.0
    inter_area = (x_right - x_left) * (y_bottom - y_top)
    area_a = max(a[2] - a[0], 0.0) * max(a[3] - a[1], 0.0)
    area_b = max(b[2] - b[0], 0.0) * max(b[3] - b[1], 0.0)
    denom = min(area_a, area_b)
    if denom <= 0:
        return 0.0
    return inter_area / denom


def _looks_like_formula(text: str) -> bool:
    stripped = text.strip()
    if len(stripped) < FORMULA_MIN_LEN:
        return False
    if FORMULA_TOKEN_RE.search(stripped):
        return True
    return False


def _should_replace_formula(latex: str, score: Optional[float]) -> bool:
    if not latex:
        return False
    if score is not None:
        try:
            score_value = float(score)
        except (TypeError, ValueError):
            score_value = None
        if score_value is not None and score_value < FORMULA_MIN_SCORE:
            return False
    return _looks_like_formula(latex)


def _merge_lines_with_formulas(
    lines: List[OcrLine], formulas: List[Dict[str, Any]]
) -> str:
    if not lines:
        return ""
    if not formulas:
        return lines_to_text(lines)

    line_rects: List[Optional[Tuple[float, float, float, float]]] = []
    for line in lines:
        line_rects.append(_normalize_box(line.get("box")))

    if not any(line_rects):
        return lines_to_text(lines)

    output_texts = [line["text"] for line in lines]
    replaced_indexes = set()
    extra_formulas: List[Dict[str, Any]] = []

    for formula in formulas:
        latex = _strip_formula_wrappers(str(formula.get("latex") or "").strip())
        if not _should_replace_formula(latex, formula.get("score")):
            continue
        formula_rect = _normalize_box(formula.get("box"))
        if not formula_rect:
            continue

        best_index = None
        best_overlap = 0.0
        for idx, line_rect in enumerate(line_rects):
            if line_rect is None or idx in replaced_indexes:
                continue
            overlap = _overlap_ratio(line_rect, formula_rect)
            if overlap > best_overlap:
                best_overlap = overlap
                best_index = idx

        if best_index is not None and best_overlap >= FORMULA_OVERLAP_THRESHOLD:
            line_text = output_texts[best_index]
            line_rect = line_rects[best_index]
            line_has_cjk = bool(CJK_RE.search(line_text))
            formula_area = (formula_rect[2] - formula_rect[0]) * (
                formula_rect[3] - formula_rect[1]
            )
            line_area = 0.0
            if line_rect is not None:
                line_area = (line_rect[2] - line_rect[0]) * (line_rect[3] - line_rect[1])
            area_ratio = formula_area / line_area if line_area > 0 else 1.0

            inline_formula = line_has_cjk and area_ratio < 0.7
            if inline_formula:
                matches = list(INLINE_MATH_RE.finditer(line_text))
                if matches:
                    match = max(matches, key=lambda m: len(m.group(0)))
                    start, end = match.span()
                    replaced = (
                        line_text[:start]
                        + _wrap_inline_formula(latex)
                        + line_text[end:]
                    )
                    output_texts[best_index] = replaced
                    replaced_indexes.add(best_index)
                else:
                    extra_formulas.append(
                        {"text": _wrap_inline_formula(latex), "rect": formula_rect}
                    )
            elif area_ratio >= 0.7 or not line_has_cjk:
                output_texts[best_index] = _wrap_formula(latex)
                replaced_indexes.add(best_index)
        else:
            extra_formulas.append({"text": _wrap_formula(latex), "rect": formula_rect})

    if not extra_formulas:
        return "\n".join([text for text in output_texts if text])

    items: List[Dict[str, Any]] = []
    for idx, (text, rect) in enumerate(zip(output_texts, line_rects)):
        if not text:
            continue
        items.append({"text": text, "rect": rect, "index": idx})
    items.extend(extra_formulas)

    if not all(item.get("rect") for item in items):
        return "\n".join([text for text in output_texts if text] + [f["text"] for f in extra_formulas])

    items.sort(key=lambda item: (item["rect"][1], item["rect"][0]))
    return "\n".join([item["text"] for item in items])


def run_fused_ocr(image_path: str) -> Tuple[str, str]:
    image_array = load_image_array(image_path)
    ocr_lines = ocr_image_lines(image_path, image_array=image_array)
    raw_text = lines_to_text(ocr_lines)

    try:
        structure_results = run_structure_ocr(image_path)
        formula_regions = extract_formula_regions(structure_results)
    except Exception:
        formula_regions = []

    fused_text = _merge_lines_with_formulas(ocr_lines, formula_regions).strip()
    if not fused_text:
        fused_text = raw_text.strip()
    return fused_text, raw_text
