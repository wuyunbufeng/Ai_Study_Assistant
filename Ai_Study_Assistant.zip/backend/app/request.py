import requests

# 从配置中获取密钥
from core.config import get_settings  # 修正导入路径
settings = get_settings()
api_key = settings.DASHSCOPE_API_KEY

# 替换为实际服务商的API测试端点
api_url = "https://bailian.console.aliyun.com/?tab=model#/api-key"
headers = {
    "Authorization": f"Bearer {api_key}"
}

try:
    response = requests.get(api_url, headers=headers, timeout=10)
    print(f"状态码: {response.status_code}")
    print(f"响应内容: {response.text[:200]}")  # 打印前200个字符

    if response.status_code == 200:
        print("✅ API密钥有效，认证成功。")
    elif response.status_code == 401:
        print("❌ 认证失败，API密钥无效或已过期。")
    elif response.status_code == 403:
        print("⛔ 认证通过但权限不足，请检查密钥的可用范围。")
    else:
        print(f"⚠️ 请求异常，状态码: {response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"🚨 网络请求失败: {e}")