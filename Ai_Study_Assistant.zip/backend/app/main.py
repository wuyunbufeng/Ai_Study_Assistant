import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .core.db import Base, engine, ensure_schema
from .routers.health import router as health_router
from .routers.audio import router as audio_router
from .routers.notes import router as notes_router
from .routers.mindmap import router as mindmap_router
from .routers.errors import router as errors_router
from .routers.auth import router as auth_router


def create_app() -> FastAPI:
    app = FastAPI(
        title="AI Lecture Note Assistant",
        version="0.1.0",
        description="Backend service for AI-powered lecture note generation.",
    )

    # Ensure data directories exist for static assets
    os.makedirs("data/error_images", exist_ok=True)
    os.makedirs("data/audio", exist_ok=True)

    # Mount static files (e.g., saved error images)
    app.mount("/static", StaticFiles(directory="data"), name="static")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health_router)
    app.include_router(auth_router)
    app.include_router(audio_router)
    app.include_router(notes_router)
    app.include_router(mindmap_router)
    app.include_router(errors_router)

    Base.metadata.create_all(bind=engine)
    ensure_schema()

    return app


app = create_app()
