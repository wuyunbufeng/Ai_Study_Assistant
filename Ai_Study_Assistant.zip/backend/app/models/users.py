from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Column, DateTime, Integer, String

from ..core.db import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    phone = Column(String(32))
    school = Column(String(120))
    class_name = Column(String(120))
    created_at = Column(DateTime, default=datetime.utcnow)


class UserCreate(BaseModel):
    username: str
    password: str
    phone: Optional[str] = None
    school: Optional[str] = None
    class_name: Optional[str] = None


class UserLogin(BaseModel):
    username: str
    password: str


class UserUpdate(BaseModel):
    username: Optional[str] = None
    phone: Optional[str] = None
    school: Optional[str] = None
    class_name: Optional[str] = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: Optional[str] = None


class UserOut(BaseModel):
    id: int
    username: str
    phone: Optional[str] = None
    school: Optional[str] = None
    class_name: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class UserUpdateOut(BaseModel):
    user: UserOut
    access_token: str
    token_type: str = "bearer"


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
