from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text

from ..core.db import Base


class MindMapNode(BaseModel):
    id: str
    text: str
    parent_id: Optional[str] = None


class MindMap(BaseModel):
    title: Optional[str] = None
    nodes: List[MindMapNode]


class MindMapRecord(Base):
    __tablename__ = "mindmaps"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    note_id = Column(Integer, ForeignKey("lecture_notes.id"), nullable=False)
    title = Column(String(200), nullable=True)
    mermaid = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class MindMapCreate(BaseModel):
    note_id: int


class MindMapOut(BaseModel):
    id: int
    note_id: int
    title: Optional[str] = None
    mermaid: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
