from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text

from ..core.db import Base


class WrongQuestion(Base):
    __tablename__ = "wrong_questions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    image_path = Column(String, nullable=False)
    raw_text = Column(Text, nullable=False)
    subject = Column(String(100), nullable=True)
    knowledge_point = Column(String(200), nullable=True)
    note = Column(Text, nullable=True)
    structured_text = Column(Text, nullable=True)
    analysis = Column(Text, nullable=True)
    analysis_error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class WrongQuestionBase(BaseModel):
    subject: Optional[str] = None
    knowledge_point: Optional[str] = None
    note: Optional[str] = None


class WrongQuestionCreate(WrongQuestionBase):
    image_path: str
    raw_text: str
    structured_text: Optional[str] = None


class WrongQuestionUpdate(BaseModel):
    subject: Optional[str] = None
    knowledge_point: Optional[str] = None
    note: Optional[str] = None


class WrongQuestionMetadataRequest(BaseModel):
    text: str


class WrongQuestionMetadataResponse(BaseModel):
    subject: Optional[str] = None
    knowledge_point: Optional[str] = None
    error: Optional[str] = None


class WrongQuestionOut(WrongQuestionBase):
    id: int
    image_path: str
    raw_text: str
    structured_text: Optional[str] = None
    analysis: Optional[str] = None
    analysis_error: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
