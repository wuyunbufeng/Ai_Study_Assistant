from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Column, DateTime, ForeignKey, Integer, JSON, String, Text

from ..core.db import Base


class NoteSection(BaseModel):
    title: str
    key_points: List[str]
    examples: Optional[List[str]] = None
    summary: Optional[str] = None


class Note(BaseModel):
    lecture_title: Optional[str] = None
    sections: List[NoteSection]
    keywords: Optional[List[str]] = None
    raw_transcript: Optional[str] = None
    audio_path: Optional[str] = None

    def to_markdown(self) -> str:
        """
        Convert the Note object into a Markdown-formatted string.
        """
        markdown = f"# {self.lecture_title or 'Lecture Notes'}\n\n"
        if self.keywords:
            markdown += f"**Keywords**: {', '.join(self.keywords)}\n\n"
        for section in self.sections:
            markdown += f"## {section.title}\n\n"
            if section.key_points:
                markdown += "### Key Points\n"
                markdown += "\n".join(f"- {point}" for point in section.key_points) + "\n\n"
            if section.examples:
                markdown += "### Examples\n"
                markdown += "\n".join(f"- {example}" for example in section.examples) + "\n\n"
            if section.summary:
                markdown += f"### Summary\n{section.summary}\n\n"
        return markdown


class LectureNote(Base):
    __tablename__ = "lecture_notes"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    lecture_title = Column(String(200), nullable=True)
    keywords = Column(JSON, nullable=True)
    sections = Column(JSON, nullable=False)
    raw_transcript = Column(Text, nullable=True)
    audio_path = Column(String(300), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class LectureNoteBase(BaseModel):
    lecture_title: Optional[str] = None
    sections: List[NoteSection]
    keywords: Optional[List[str]] = None
    raw_transcript: Optional[str] = None
    audio_path: Optional[str] = None


class LectureNoteCreate(LectureNoteBase):
    pass


class LectureNoteOut(LectureNoteBase):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
