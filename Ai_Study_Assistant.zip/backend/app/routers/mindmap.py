from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import desc
from sqlalchemy.orm import Session

from ..core.db import get_db
from ..core.security import get_current_user
from ..models.mindmap import MindMapCreate, MindMapOut, MindMapRecord
from ..models.notes import LectureNote, Note, NoteSection
from ..models.users import User
from ..services.mindmap import note_to_mermaid

router = APIRouter(prefix="/api/mindmap", tags=["mindmap"])


def _note_from_record(record: LectureNote) -> Note:
    sections = [NoteSection(**section) for section in (record.sections or [])]
    return Note(
        lecture_title=record.lecture_title,
        sections=sections,
        keywords=record.keywords,
        raw_transcript=record.raw_transcript,
    )


@router.post("/from_note", response_model=MindMapOut)
def generate_mindmap_from_note(
    payload: MindMapCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> MindMapOut:
    note_record = (
        db.query(LectureNote)
        .filter(
            LectureNote.id == payload.note_id,
            LectureNote.user_id == current_user.id,
        )
        .first()
    )
    if not note_record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Note not found"
        )

    try:
        mermaid_syntax = note_to_mermaid(_note_from_record(note_record))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate mind map: {exc}",
        ) from exc

    record = MindMapRecord(
        user_id=current_user.id,
        note_id=note_record.id,
        title=note_record.lecture_title,
        mermaid=mermaid_syntax,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("", response_model=List[MindMapOut])
def list_mindmaps(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> List[MindMapOut]:
    return (
        db.query(MindMapRecord)
        .filter(MindMapRecord.user_id == current_user.id)
        .order_by(desc(MindMapRecord.created_at))
        .all()
    )


@router.get("/{mindmap_id}", response_model=MindMapOut)
def get_mindmap(
    mindmap_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> MindMapOut:
    record = (
        db.query(MindMapRecord)
        .filter(
            MindMapRecord.id == mindmap_id,
            MindMapRecord.user_id == current_user.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Mind map not found"
        )
    return record
