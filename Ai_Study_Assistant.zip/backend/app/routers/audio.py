import hashlib
import os
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, UploadFile, File, HTTPException, status, Depends

from ..models.notes import Note
from ..models.users import User
from ..core.security import get_current_user
from ..services.notes import generate_note_from_audio

router = APIRouter(prefix="/api/audio", tags=["audio"])

ALLOWED_MIME_TYPES = {
    "audio/wav",
    "audio/mpeg",
    "audio/mp3",
    "audio/x-wav",
    "audio/webm",
    "audio/mp4",
    "audio/x-m4a",
}


def _hash_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


@router.post("/upload", response_model=Note)
async def upload_audio(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
) -> Note:
    if file.content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type: {file.content_type}",
        )

    audio_dir = Path("data") / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)

    original_name = Path(file.filename).name if file.filename else ""
    suffix = Path(original_name).suffix or ".bin"
    stem = Path(original_name).stem or uuid4().hex
    audio_filename = f"{stem}{suffix}"
    audio_path = audio_dir / audio_filename
    did_write = False

    try:
        contents = await file.read()
        if len(contents) > 50 * 1024 * 1024:  # 50MB
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File size exceeds 50MB limit.",
            )

        file_hash = hashlib.sha256(contents).hexdigest()
        if audio_path.exists():
            try:
                existing_hash = _hash_file(audio_path)
            except OSError:
                existing_hash = None
            if existing_hash != file_hash:
                audio_filename = f"{stem}-{file_hash[:8]}{suffix}"
                audio_path = audio_dir / audio_filename

        if not audio_path.exists():
            with audio_path.open("wb") as f:
                f.write(contents)
            did_write = True

        # Call the updated generate_note_from_audio
        audio_rel_path = (Path("audio") / audio_path.name).as_posix()
        note = await generate_note_from_audio(str(audio_path))
        note.audio_path = audio_rel_path
        return note
    except HTTPException:
        if did_write and audio_path.exists():
            try:
                os.remove(audio_path)
            except OSError:
                print(f"Warning: could not remove audio file {audio_path}")
        raise
    except Exception as exc:  # pylint: disable=broad-except
        if did_write and audio_path.exists():
            try:
                os.remove(audio_path)
            except OSError:
                print(f"Warning: could not remove audio file {audio_path}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process audio: {exc}",
        ) from exc
