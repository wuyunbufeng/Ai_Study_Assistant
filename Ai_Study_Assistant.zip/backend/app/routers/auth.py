from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..core.config import get_settings
from ..core.db import get_db
from ..core.security import create_access_token, get_current_user, hash_password, verify_password
from ..models.users import (
    PasswordChange,
    Token,
    User,
    UserCreate,
    UserLogin,
    UserOut,
    UserUpdate,
    UserUpdateOut,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _validate_password(password: str) -> None:
    if len(password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 8 characters long.",
        )
    has_alpha = any(ch.isalpha() for ch in password)
    has_digit = any(ch.isdigit() for ch in password)
    if not (has_alpha and has_digit):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must include letters and numbers.",
        )


@router.post("/register", response_model=UserOut)
def register(payload: UserCreate, db: Session = Depends(get_db)) -> UserOut:
    username = payload.username.strip()
    if not username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username is required.",
        )
    _validate_password(payload.password)

    existing = db.query(User).filter(User.username == username).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Username already exists."
        )

    user = User(
        username=username,
        password_hash=hash_password(payload.password),
        phone=payload.phone,
        school=payload.school,
        class_name=payload.class_name,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=Token)
def login(payload: UserLogin, db: Session = Depends(get_db)) -> Token:
    username = payload.username.strip()
    if not username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username is required.",
        )
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials."
        )

    settings = get_settings()
    access_token = create_access_token(
        {"sub": user.username, "uid": user.id},
        expires_delta=timedelta(minutes=settings.JWT_EXPIRE_MINUTES),
    )
    return Token(access_token=access_token, token_type="bearer")


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)) -> UserOut:
    return current_user


@router.patch("/me", response_model=UserUpdateOut)
def update_me(
    payload: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> UserUpdateOut:
    if payload.username is not None:
        username = payload.username.strip()
        if not username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username is required.",
            )
        if username != current_user.username:
            existing = db.query(User).filter(User.username == username).first()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Username already exists.",
                )
            current_user.username = username

    if payload.phone is not None:
        phone = payload.phone.strip()
        current_user.phone = phone or None

    if payload.school is not None:
        school = payload.school.strip()
        current_user.school = school or None

    if payload.class_name is not None:
        class_name = payload.class_name.strip()
        current_user.class_name = class_name or None

    db.add(current_user)
    db.commit()
    db.refresh(current_user)

    settings = get_settings()
    access_token = create_access_token(
        {"sub": current_user.username, "uid": current_user.id},
        expires_delta=timedelta(minutes=settings.JWT_EXPIRE_MINUTES),
    )
    return UserUpdateOut(access_token=access_token, user=current_user)


@router.post("/change-password")
def change_password(
    payload: PasswordChange,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    if not verify_password(payload.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current password is incorrect.",
        )

    if payload.new_password is None:
        return {"status": "verified"}

    _validate_password(payload.new_password)
    current_user.password_hash = hash_password(payload.new_password)
    db.add(current_user)
    db.commit()
    return {"status": "updated"}
