from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import desc
from sqlalchemy.orm import Session

from ..core.db import get_db
from ..core.security import get_current_user
from ..models.mindmap import MindMapRecord
from ..models.notes import LectureNote, LectureNoteCreate, LectureNoteOut, NoteSection
from ..models.users import User

router = APIRouter(prefix="/api/notes", tags=["notes"])


def _serialize_sections(sections: List[NoteSection]) -> List[dict]:
    return [section.model_dump() for section in sections]


@router.post("/save", response_model=LectureNoteOut)
def save_note(
    payload: LectureNoteCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> LectureNoteOut:
    record = LectureNote(
        user_id=current_user.id,
        lecture_title=payload.lecture_title,
        keywords=payload.keywords,
        sections=_serialize_sections(payload.sections),
        raw_transcript=payload.raw_transcript,
        audio_path=payload.audio_path,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("", response_model=List[LectureNoteOut])
def list_notes(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> List[LectureNoteOut]:
    return (
        db.query(LectureNote)
        .filter(LectureNote.user_id == current_user.id)
        .order_by(desc(LectureNote.created_at))
        .all()
    )


@router.get("/{note_id}", response_model=LectureNoteOut)
def get_note(
    note_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> LectureNoteOut:
    record = (
        db.query(LectureNote)
        .filter(LectureNote.id == note_id, LectureNote.user_id == current_user.id)
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Note not found"
        )
    return record


@router.delete("/{note_id}")
def delete_note(
    note_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    record = (
        db.query(LectureNote)
        .filter(LectureNote.id == note_id, LectureNote.user_id == current_user.id)
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Note not found"
        )

    db.query(MindMapRecord).filter(
        MindMapRecord.note_id == note_id, MindMapRecord.user_id == current_user.id
    ).delete(synchronize_session=False)
    db.delete(record)
    db.commit()
    return {"status": "deleted"}
