import logging
import uuid
from pathlib import Path
from typing import List

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    HTTPException,
    UploadFile,
    status,
)
from sqlalchemy import desc
from sqlalchemy.orm import Session

from ..core.db import SessionLocal, get_db
from ..core.security import get_current_user
from ..models.errors import (
    WrongQuestion,
    WrongQuestionCreate,
    WrongQuestionMetadataRequest,
    WrongQuestionMetadataResponse,
    WrongQuestionOut,
    WrongQuestionUpdate,
)
from ..models.users import User
from ..services.llm import analyze_wrong_question, extract_error_metadata
from ..services.ocr_fusion import run_fused_ocr

router = APIRouter(prefix="/api/errors", tags=["errors"])
logger = logging.getLogger(__name__)


def _generate_analysis_for_question(question_id: int) -> None:
    db = SessionLocal()
    try:
        record = db.query(WrongQuestion).filter(WrongQuestion.id == question_id).first()
        if not record:
            return

        record.analysis_error = None
        structured_text = (record.structured_text or "").strip()
        if not structured_text:
            image_abs_path = Path("data") / record.image_path
            if image_abs_path.exists():
                try:
                    structured_text = run_fused_ocr(str(image_abs_path))[0].strip()
                except Exception:
                    logger.exception(
                        "Structured OCR failed for question_id=%s", question_id
                    )
            if structured_text:
                record.structured_text = structured_text
                db.commit()

        try:
            analysis_input = structured_text or record.raw_text
            record.analysis = analyze_wrong_question(
                analysis_input,
                subject=record.subject,
                knowledge_point=record.knowledge_point,
                note=record.note,
            )
            record.analysis_error = None
            db.commit()
        except Exception:
            db.rollback()
            record = db.query(WrongQuestion).filter(WrongQuestion.id == question_id).first()
            if record:
                record.analysis_error = "LLM analysis failed. Check server logs."
                db.commit()
            logger.exception("LLM analysis failed for question_id=%s", question_id)
    except Exception:
        db.rollback()
        logger.exception("Failed to generate analysis for question_id=%s", question_id)
    finally:
        db.close()


@router.post("/ocr")
async def upload_and_ocr(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
) -> dict:
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported file type, please upload an image.",
        )

    suffix = Path(file.filename).suffix
    filename = f"{uuid.uuid4().hex}{suffix}"
    user_dir = Path("data") / "error_images" / str(current_user.id)
    user_dir.mkdir(parents=True, exist_ok=True)
    image_rel_path = Path("error_images") / str(current_user.id) / filename
    image_abs_path = Path("data") / image_rel_path

    try:
        contents = await file.read()
        with image_abs_path.open("wb") as f:
            f.write(contents)

        try:
            structured_text, raw_text = run_fused_ocr(str(image_abs_path))
        except Exception as exc:
            logger.exception("OCR failed for image=%s", image_abs_path)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"OCR failed: {exc}",
            ) from exc
    except HTTPException:
        raise
    except Exception as exc:  # pylint: disable=broad-except
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"OCR failed: {exc}",
        ) from exc

    image_rel_web = image_rel_path.as_posix()
    return {
        "image_path": image_rel_web,
        "image_url": f"/static/{image_rel_web}",
        "raw_text": raw_text,
        "structured_text": structured_text,
    }


@router.post("/metadata", response_model=WrongQuestionMetadataResponse)
def infer_metadata(
    payload: WrongQuestionMetadataRequest,
    current_user: User = Depends(get_current_user),
) -> WrongQuestionMetadataResponse:
    text = (payload.text or "").strip()
    if not text:
        return WrongQuestionMetadataResponse(subject=None, knowledge_point=None)
    try:
        data = extract_error_metadata(text)
    except Exception as exc:
        logger.exception("Metadata inference failed.")
        return WrongQuestionMetadataResponse(
            subject=None,
            knowledge_point=None,
            error=str(exc)[:200],
        )
    return WrongQuestionMetadataResponse(**data)


@router.post("/save", response_model=WrongQuestionOut)
def save_wrong_question(
    payload: WrongQuestionCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> WrongQuestionOut:
    record = WrongQuestion(
        user_id=current_user.id,
        image_path=payload.image_path,
        raw_text=payload.raw_text,
        structured_text=payload.structured_text,
        subject=payload.subject,
        knowledge_point=payload.knowledge_point,
        note=payload.note,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    background_tasks.add_task(_generate_analysis_for_question, record.id)
    return record


@router.post("/{question_id}/analysis")
def regenerate_analysis(
    question_id: int,
    background_tasks: BackgroundTasks,
    force: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    record = (
        db.query(WrongQuestion)
        .filter(
            WrongQuestion.id == question_id,
            WrongQuestion.user_id == current_user.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Question not found"
        )
    if record.analysis and not force:
        return {"status": "exists"}

    record.analysis = None
    record.analysis_error = None
    record.structured_text = None
    db.commit()
    background_tasks.add_task(_generate_analysis_for_question, record.id)
    return {"status": "queued"}


@router.get("", response_model=List[WrongQuestionOut])
def list_wrong_questions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> List[WrongQuestionOut]:
    results = (
        db.query(WrongQuestion)
        .filter(WrongQuestion.user_id == current_user.id)
        .order_by(desc(WrongQuestion.created_at))
        .all()
    )
    return results


@router.get("/{question_id}", response_model=WrongQuestionOut)
def get_wrong_question(
    question_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> WrongQuestionOut:
    record = (
        db.query(WrongQuestion)
        .filter(
            WrongQuestion.id == question_id,
            WrongQuestion.user_id == current_user.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Question not found"
        )
    return record


@router.patch("/{question_id}", response_model=WrongQuestionOut)
def update_wrong_question(
    question_id: int,
    payload: WrongQuestionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> WrongQuestionOut:
    record = (
        db.query(WrongQuestion)
        .filter(
            WrongQuestion.id == question_id,
            WrongQuestion.user_id == current_user.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Question not found"
        )

    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(record, key, value)
    db.commit()
    db.refresh(record)
    return record


@router.delete("/{question_id}")
def delete_wrong_question(
    question_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    record = (
        db.query(WrongQuestion)
        .filter(
            WrongQuestion.id == question_id,
            WrongQuestion.user_id == current_user.id,
        )
        .first()
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Question not found"
        )

    db.delete(record)
    db.commit()

    return {"status": "deleted"}
