from functools import lru_cache
import logging
import os
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    DASHSCOPE_API_KEY: str = Field(default="", env="DASHSCOPE_API_KEY")
    asr_model_name: str = Field(default="whisper-1", env="ASR_MODEL_NAME")
    llm_model_name: str = Field(default="qwen3-max", env="LLM_MODEL_NAME")
    JWT_SECRET: str = Field(default="change-me", env="JWT_SECRET")
    JWT_ALGORITHM: str = Field(default="HS256", env="JWT_ALGORITHM")
    JWT_EXPIRE_MINUTES: int = Field(default=60 * 24, env="JWT_EXPIRE_MINUTES")

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache()
def get_settings() -> Settings:
    """
    Cached settings loader so the application reads environment variables once.
    """
    settings = Settings()
    logger.info("Loaded DASHSCOPE_API_KEY: %s", os.getenv("DASHSCOPE_API_KEY"))  # Log the raw environment variable
    logger.info("Settings DASHSCOPE_API_KEY: %s", settings.DASHSCOPE_API_KEY)  # Log the value loaded by Pydantic
    return settings
