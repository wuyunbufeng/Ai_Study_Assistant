import os

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import declarative_base, sessionmaker

# Ensure data directory exists for SQLite and stored assets.
os.makedirs("data", exist_ok=True)

engine = create_engine(
    "sqlite:///./data/app.db", connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _add_column_if_missing(
    conn, table_name: str, column_name: str, column_def: str
) -> None:
    inspector = inspect(conn)
    if table_name not in inspector.get_table_names():
        return
    columns = [col["name"] for col in inspector.get_columns(table_name)]
    if column_name in columns:
        return
    conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_def}"))


def ensure_schema() -> None:
    with engine.begin() as conn:
        _add_column_if_missing(conn, "users", "phone", "phone TEXT")
        _add_column_if_missing(conn, "users", "school", "school TEXT")
        _add_column_if_missing(conn, "users", "class_name", "class_name TEXT")
        _add_column_if_missing(conn, "lecture_notes", "user_id", "user_id INTEGER")
        _add_column_if_missing(conn, "lecture_notes", "audio_path", "audio_path TEXT")
        _add_column_if_missing(conn, "mindmaps", "user_id", "user_id INTEGER")
        _add_column_if_missing(conn, "wrong_questions", "user_id", "user_id INTEGER")
        _add_column_if_missing(
            conn, "wrong_questions", "structured_text", "structured_text TEXT"
        )
        _add_column_if_missing(conn, "wrong_questions", "analysis", "analysis TEXT")
        _add_column_if_missing(
            conn, "wrong_questions", "analysis_error", "analysis_error TEXT"
        )
