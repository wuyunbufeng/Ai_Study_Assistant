# OCR 调参指南

本文说明 OCR 在代码中的位置，以及常用可调参数。描述重点是“数值调高会发生什么”
（通常更严格或更大，具体取决于参数类型）。

## 代码位置

- API 入口：`backend/app/routers/errors.py`（`POST /api/errors/ocr`）
- 文本 OCR（PaddleOCR）：`backend/app/services/ocr.py`
- 结构与公式 OCR（PP-StructureV3）：`backend/app/services/structure_ocr.py`
- OCR 融合逻辑：`backend/app/services/ocr_fusion.py`
- 前端调用：`frontend/src/components/ErrorBookView.tsx`

## PaddleOCR 文本识别参数（backend/app/services/ocr.py）

- `det_db_thresh`（默认 0.2）
  - 越高：文本像素更难被判定为文本，框更少，噪声更少，但漏检更多。
- `det_db_box_thresh`（默认 0.35）
  - 越高：候选文本框更少，精度更高、召回更低。
- `det_db_unclip_ratio`（默认 1.8）
  - 越高：检测框外扩更多，更容易覆盖完整文字，但可能合并相邻行。
- `text_rec_score_thresh` 或 `drop_score`（默认 0.25）
  - 越高：过滤更多低置信度结果，输出更干净，但会丢字。
- `MAX_SIDE_LIMIT`（默认 3200）
  - 越高：缩放更少、细节更多，但更慢、占用内存更大。
- `lang`（默认 "ch"）
  - 语言模型选择；需要其他语言时调整。
- `ocr_version`（默认 "PP-OCRv5"）
  - OCR 引擎版本选择；切换会影响精度和速度。

## 结构 OCR 参数（backend/app/services/structure_ocr.py）

- `FORMULA_DET_THRESH`（默认 0.10）
  - 越高：公式区域更难被检测到，误检少但漏检多。
- `text_det_limit_side_len`（默认 8000）
  - 越高：缩放更少、速度更慢、内存更高，可能更准。
- `use_formula_recognition`（默认 True）
  - True：识别公式；False：更快但无公式输出。
- `use_table_recognition`、`use_chart_recognition`、`use_seal_recognition`
  - 默认 False；只有需要时再开启。

## OCR 融合参数（backend/app/services/ocr_fusion.py）

- `FORMULA_OVERLAP_THRESHOLD`（默认 0.35）
  - 越高：公式替换文本更难发生，替换次数更少。
- `FORMULA_MIN_SCORE`（默认 0.4）
  - 越高：只保留更高置信度公式，公式数量变少。
- `FORMULA_MIN_LEN`（默认 2）
  - 越高：短公式更容易被忽略。
