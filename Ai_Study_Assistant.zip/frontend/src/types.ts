export type NoteSection = {
  title: string;
  key_points: string[];
  examples?: string[] | null;
  summary?: string | null;
};

export type Note = {
  id?: number;
  lecture_title?: string | null;
  sections: NoteSection[];
  keywords?: string[] | null;
  raw_transcript?: string | null;
  audio_path?: string | null;
  created_at?: string;
};
