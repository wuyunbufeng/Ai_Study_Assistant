export interface WrongQuestion {
  id: number;
  image_path: string;
  image_url?: string;
  raw_text: string;
  structured_text?: string;
  subject?: string;
  knowledge_point?: string;
  note?: string;
  analysis?: string;
  analysis_error?: string;
  created_at: string;
}
