export interface User {
  id: number;
  username: string;
  phone?: string | null;
  school?: string | null;
  class_name?: string | null;
  created_at: string;
}
