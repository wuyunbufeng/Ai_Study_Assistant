export interface MindMapEntry {
  id: number;
  note_id: number;
  title?: string | null;
  mermaid: string;
  created_at: string;
}
