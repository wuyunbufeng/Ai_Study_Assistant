import { useEffect, useMemo, useState } from "react";
import { WrongQuestion } from "../types/errorBook";

const API_BASE = "http://127.0.0.1:8000";

type Props = {
  token: string;
};

type RadarDatum = {
  label: string;
  value: number;
  percent: number;
};

type BarDatum = {
  label: string;
  value: number;
};

const SUBJECT_LIMIT = 8;

const formatLabel = (label: string) => {
  if (label.length <= 12) return label;
  return `${label.slice(0, 11)}…`;
};

const normalizeSubject = (subject?: string | null) => {
  const value = (subject || "").trim();
  return value || "Uncategorized";
};

const normalizeKnowledge = (knowledge?: string | null) => {
  const value = (knowledge || "").trim();
  return value || "Unknown";
};

const RadarChart = ({ data }: { data: RadarDatum[] }) => {
  if (data.length < 3) {
    return (
      <div className="empty-state" style={{ padding: 20 }}>
        Add at least 3 subjects to render the radar chart.
      </div>
    );
  }

  const size = 320;
  const center = size / 2;
  const radius = size * 0.34;
  const rings = [0.33, 0.66, 1];
  const angleStep = (Math.PI * 2) / data.length;
  const maxPercent = Math.max(...data.map((item) => item.percent), 0.01);
  const scaledPercent = (percent: number) => Math.min(1, percent / maxPercent);

  const ringPoints = (scale: number) =>
    data
      .map((_, idx) => {
        const angle = -Math.PI / 2 + idx * angleStep;
        const x = center + Math.cos(angle) * radius * scale;
        const y = center + Math.sin(angle) * radius * scale;
        return `${x},${y}`;
      })
      .join(" ");

  const areaPoints = data
    .map((item, idx) => {
      const angle = -Math.PI / 2 + idx * angleStep;
      const r = radius * scaledPercent(item.percent);
      const x = center + Math.cos(angle) * r;
      const y = center + Math.sin(angle) * r;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <div style={{ width: "100%", maxWidth: 320, aspectRatio: "1 / 1" }}>
      <svg
        width="100%"
        height="100%"
        viewBox={`0 0 ${size} ${size}`}
        preserveAspectRatio="xMidYMid meet"
      >
      {rings.map((scale) => (
        <polygon
          key={scale}
          points={ringPoints(scale)}
          fill="none"
          stroke="var(--border)"
          strokeWidth={1}
        />
      ))}
      {data.map((_, idx) => {
        const angle = -Math.PI / 2 + idx * angleStep;
        const x = center + Math.cos(angle) * radius;
        const y = center + Math.sin(angle) * radius;
        return <line key={idx} x1={center} y1={center} x2={x} y2={y} stroke="var(--border)" />;
      })}
      <polygon
        points={areaPoints}
        fill="rgba(75, 123, 236, 0.22)"
        stroke="var(--accent)"
        strokeWidth={2}
      />
      {data.map((item, idx) => {
        const angle = -Math.PI / 2 + idx * angleStep;
        const r = radius * scaledPercent(item.percent);
        const x = center + Math.cos(angle) * r;
        const y = center + Math.sin(angle) * r;
        return <circle key={item.label} cx={x} cy={y} r={3.5} fill="var(--accent)" />;
      })}
      {data.map((item, idx) => {
        const angle = -Math.PI / 2 + idx * angleStep;
        const labelRadius = radius + 18;
        const x = center + Math.cos(angle) * labelRadius;
        const y = center + Math.sin(angle) * labelRadius;
        const anchor =
          x > center + 12 ? "start" : x < center - 12 ? "end" : "middle";
        return (
          <text
            key={`${item.label}-label`}
            x={x}
            y={y}
            fontSize={11}
            fill="var(--muted)"
            textAnchor={anchor}
          >
            {formatLabel(item.label)}
          </text>
        );
      })}
      </svg>
    </div>
  );
};

const BarChart = ({ data }: { data: BarDatum[] }) => {
  if (data.length === 0) {
    return (
      <div className="empty-state" style={{ padding: 20 }}>
        No knowledge points yet.
      </div>
    );
  }

  const maxValue = Math.max(...data.map((item) => item.value), 1);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {data.map((item) => (
        <div key={item.label}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
            <div style={{ fontWeight: 600 }}>{formatLabel(item.label)}</div>
            <div className="muted" style={{ fontSize: 12 }}>
              {item.value}
            </div>
          </div>
          <div
            style={{
              height: 10,
              background: "#eef2fb",
              borderRadius: 999,
              overflow: "hidden",
              marginTop: 6,
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${(item.value / maxValue) * 100}%`,
                background: "linear-gradient(135deg, var(--accent), #3e64e6)",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

export default function DashboardView({ token }: Props) {
  const [questions, setQuestions] = useState<WrongQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchErrors = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${API_BASE}/api/errors`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || "Failed to load error book data.");
        }
        const data: WrongQuestion[] = await res.json();
        setQuestions(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unexpected error";
        setError(message);
      } finally {
        setLoading(false);
      }
    };
    fetchErrors();
  }, [token]);

  const subjectData = useMemo<RadarDatum[]>(() => {
    const counts = new Map<string, number>();
    questions.forEach((q) => {
      const label = normalizeSubject(q.subject);
      counts.set(label, (counts.get(label) || 0) + 1);
    });

    const entries = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) return [];

    let trimmed = entries;
    if (entries.length > SUBJECT_LIMIT) {
      const top = entries.slice(0, SUBJECT_LIMIT - 1);
      const rest = entries.slice(SUBJECT_LIMIT - 1);
      const restValue = rest.reduce((sum, item) => sum + item[1], 0);
      trimmed = [...top, ["Other", restValue]];
    }

    const total = trimmed.reduce((sum, item) => sum + item[1], 0) || 1;
    return trimmed.map(([label, value]) => ({
      label,
      value,
      percent: value / total,
    }));
  }, [questions]);

  const knowledgeData = useMemo<BarDatum[]>(() => {
    const counts = new Map<string, number>();
    questions.forEach((q) => {
      const label = normalizeKnowledge(q.knowledge_point);
      counts.set(label, (counts.get(label) || 0) + 1);
    });
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([label, value]) => ({ label, value }));
  }, [questions]);

  return (
    <div className="grid two-column">
      <div className="card">
        <h3 className="section-title">Subject Distribution</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Radar chart of wrong questions by subject.
        </p>
        {loading ? (
          <div className="empty-state">Loading subject data...</div>
        ) : error ? (
          <span className="status-pill error">{error}</span>
        ) : (
          <div style={{ display: "flex", justifyContent: "center" }}>
            <RadarChart data={subjectData} />
          </div>
        )}
      </div>

      <div className="card">
        <h3 className="section-title">Top 10 Knowledge Points</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Most frequent knowledge points from your error book.
        </p>
        {loading ? (
          <div className="empty-state">Loading knowledge points...</div>
        ) : error ? (
          <span className="status-pill error">{error}</span>
        ) : (
          <BarChart data={knowledgeData} />
        )}
      </div>
    </div>
  );
}
