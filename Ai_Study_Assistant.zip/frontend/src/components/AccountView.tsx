import { useEffect, useState } from "react";
import { User } from "../types/auth";

const API_BASE = "http://127.0.0.1:8000";

type Props = {
  user: User;
  token: string;
  onUserUpdate: (user: User, accessToken?: string) => void;
  onLogout: () => void;
};

type UserUpdateResponse = {
  user: User;
  access_token: string;
  token_type: string;
};

export default function AccountView({ user, token, onUserUpdate, onLogout }: Props) {
  const [username, setUsername] = useState(user.username);
  const [phone, setPhone] = useState(user.phone ?? "");
  const [school, setSchool] = useState(user.school ?? "");
  const [className, setClassName] = useState(user.class_name ?? "");
  const [editMode, setEditMode] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [passwordStep, setPasswordStep] = useState<"verify" | "change">("verify");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordNotice, setPasswordNotice] = useState<string | null>(null);
  const fallback = "Not provided";

  useEffect(() => {
    setUsername(user.username);
    setPhone(user.phone ?? "");
    setSchool(user.school ?? "");
    setClassName(user.class_name ?? "");
  }, [user]);

  const resetSaveStatus = () => {
    setSaveError(null);
    setSaveSuccess(null);
  };

  const resetFields = () => {
    setUsername(user.username);
    setPhone(user.phone ?? "");
    setSchool(user.school ?? "");
    setClassName(user.class_name ?? "");
  };

  const displayValue = (value: string | null | undefined) => {
    const trimmed = value?.trim();
    return trimmed ? trimmed : fallback;
  };

  const validatePassword = (value: string) => {
    if (value.length < 8) return "Password must be at least 8 characters.";
    const hasAlpha = /[a-zA-Z]/.test(value);
    const hasDigit = /\d/.test(value);
    if (!hasAlpha || !hasDigit) return "Password must include letters and numbers.";
    return null;
  };

  const normalize = (value: string) => value.trim();
  const isDirty =
    normalize(username) !== user.username ||
    normalize(phone) !== (user.phone ?? "") ||
    normalize(school) !== (user.school ?? "") ||
    normalize(className) !== (user.class_name ?? "");

  const handleSave = async () => {
    resetSaveStatus();
    setPasswordNotice(null);

    const trimmedUsername = username.trim();
    if (!trimmedUsername) {
      setSaveError("Username is required.");
      return;
    }

    setSaveLoading(true);
    try {
      const payload = {
        username: trimmedUsername,
        phone: normalize(phone) || null,
        school: normalize(school) || null,
        class_name: normalize(className) || null,
      };
      const res = await fetch(`${API_BASE}/api/auth/me`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to update account.");
      }
      const data: UserUpdateResponse = await res.json();
      if (!data?.user) {
        throw new Error("Invalid response from server.");
      }
      onUserUpdate(data.user, data.access_token);
      setSaveSuccess("Profile updated.");
      setEditMode(false);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setSaveError(message);
    } finally {
      setSaveLoading(false);
    }
  };

  const handleEdit = () => {
    resetSaveStatus();
    setPasswordNotice(null);
    setEditMode(true);
  };

  const handleCancelEdit = () => {
    resetFields();
    resetSaveStatus();
    setEditMode(false);
  };

  const openPasswordModal = () => {
    setPasswordModalOpen(true);
    setPasswordStep("verify");
    setCurrentPassword("");
    setNewPassword("");
    setPasswordError(null);
    setPasswordNotice(null);
  };

  const closePasswordModal = () => {
    setPasswordModalOpen(false);
    setPasswordStep("verify");
    setCurrentPassword("");
    setNewPassword("");
    setPasswordError(null);
    setPasswordLoading(false);
  };

  const handleLogoutClick = () => {
    setPasswordModalOpen(false);
    setPasswordStep("verify");
    setCurrentPassword("");
    setNewPassword("");
    setPasswordError(null);
    setPasswordNotice(null);
    setEditMode(false);
    resetSaveStatus();
    onLogout();
  };

  const handleVerifyPassword = async () => {
    setPasswordError(null);
    setPasswordNotice(null);

    if (!currentPassword) {
      setPasswordError("Current password is required.");
      return;
    }

    setPasswordLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/change-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ current_password: currentPassword }),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Password verification failed.");
      }
      setPasswordStep("change");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setPasswordError(message);
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleChangePassword = async () => {
    setPasswordError(null);
    setPasswordNotice(null);

    const pwdError = validatePassword(newPassword);
    if (pwdError) {
      setPasswordError(pwdError);
      return;
    }

    setPasswordLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/auth/change-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to update password.");
      }
      setPasswordNotice("Password updated.");
      closePasswordModal();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setPasswordError(message);
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <div className="card">
      <h3 className="section-title">Account</h3>
      <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
        Manage your session and view profile information.
      </p>

      <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
        <div>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            Username
          </label>
          {editMode ? (
            <input
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                resetSaveStatus();
              }}
              placeholder="Enter your username"
              autoComplete="username"
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          ) : (
            <div style={{ fontWeight: 600 }}>{displayValue(user.username)}</div>
          )}
        </div>
        <div>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            Phone
          </label>
          {editMode ? (
            <input
              type="tel"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                resetSaveStatus();
              }}
              placeholder="Enter your phone number"
              autoComplete="tel"
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          ) : (
            <div>{displayValue(user.phone)}</div>
          )}
        </div>
        <div>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            School
          </label>
          {editMode ? (
            <input
              value={school}
              onChange={(e) => {
                setSchool(e.target.value);
                resetSaveStatus();
              }}
              placeholder="Enter your school"
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          ) : (
            <div>{displayValue(user.school)}</div>
          )}
        </div>
        <div>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            Class
          </label>
          {editMode ? (
            <input
              value={className}
              onChange={(e) => {
                setClassName(e.target.value);
                resetSaveStatus();
              }}
              placeholder="Enter your class"
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          ) : (
            <div>{displayValue(user.class_name)}</div>
          )}
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        {editMode ? (
          <>
            <button
              className="button primary"
              onClick={handleSave}
              disabled={saveLoading || !isDirty}
            >
              {saveLoading ? "Saving..." : "Save changes"}
            </button>
            <button className="button secondary" onClick={handleCancelEdit} disabled={saveLoading}>
              Cancel
            </button>
          </>
        ) : (
          <button className="button primary" onClick={handleEdit}>
            Edit
          </button>
        )}
        {saveError && <span className="status-pill error">{saveError}</span>}
        {saveSuccess && <span className="status-pill success">{saveSuccess}</span>}
      </div>

      <div
        style={{ marginTop: 16, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}
      >
        <button className="button secondary" onClick={openPasswordModal}>
          Change password
        </button>
        <button className="button secondary" onClick={handleLogoutClick}>
          Logout
        </button>
        {passwordNotice && <span className="status-pill success">{passwordNotice}</span>}
      </div>

      {passwordModalOpen && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div className="card" style={{ width: "min(480px, 92vw)" }}>
            <h3 className="section-title">Change Password</h3>
            <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
              {passwordStep === "verify"
                ? "Enter your current password to continue."
                : "Current password verified. Enter a new password."}
            </p>

            {passwordStep === "verify" ? (
              <div>
                <label className="muted" style={{ display: "block", marginBottom: 6 }}>
                  Current password
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  autoComplete="new-password"
                  name="current_password"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                    border: "1px solid #d4d9e2",
                    padding: 10,
                  }}
                />
              </div>
            ) : (
              <div>
                <label className="muted" style={{ display: "block", marginBottom: 6 }}>
                  New password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  autoComplete="new-password"
                  style={{
                    width: "100%",
                    borderRadius: 10,
                    border: "1px solid #d4d9e2",
                    padding: 10,
                  }}
                />
                <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>
                  Password must be at least 8 characters and include letters + numbers.
                </div>
              </div>
            )}

            {passwordError && (
              <div style={{ marginTop: 12 }}>
                <span className="status-pill error">{passwordError}</span>
              </div>
            )}

            <div
              style={{
                marginTop: 16,
                display: "flex",
                gap: 10,
                justifyContent: "flex-end",
              }}
            >
              <button className="button secondary" onClick={closePasswordModal}>
                Cancel
              </button>
              {passwordStep === "verify" ? (
                <button
                  className="button primary"
                  onClick={handleVerifyPassword}
                  disabled={passwordLoading}
                >
                  {passwordLoading ? "Verifying..." : "Verify"}
                </button>
              ) : (
                <button
                  className="button primary"
                  onClick={handleChangePassword}
                  disabled={passwordLoading}
                >
                  {passwordLoading ? "Updating..." : "Update password"}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
