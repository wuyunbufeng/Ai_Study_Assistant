import { useState } from "react";

const API_BASE = "http://127.0.0.1:8000";

type Mode = "login" | "register";

type Props = {
  onAuthSuccess: (token: string) => void;
};

export default function AuthView({ onAuthSuccess }: Props) {
  const [mode, setMode] = useState<Mode>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const resetStatus = () => {
    setError(null);
    setSuccess(null);
  };

  const validatePassword = (value: string) => {
    if (value.length < 8) return "Password must be at least 8 characters.";
    const hasAlpha = /[a-zA-Z]/.test(value);
    const hasDigit = /\d/.test(value);
    if (!hasAlpha || !hasDigit) return "Password must include letters and numbers.";
    return null;
  };

  const handleSubmit = async () => {
    resetStatus();
    if (!username.trim()) {
      setError("Username is required.");
      return;
    }
    if (mode === "register") {
      const pwdError = validatePassword(password);
      if (pwdError) {
        setError(pwdError);
        return;
      }
    }
    if (!password) {
      setError("Password is required.");
      return;
    }

    setLoading(true);
    try {
      if (mode === "register") {
        const registerRes = await fetch(`${API_BASE}/api/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: username.trim(), password }),
        });
        if (!registerRes.ok) {
          const msg = await registerRes.text();
          throw new Error(msg || "Registration failed");
        }
        setSuccess("Registration successful. Logging in...");
      }

      const loginRes = await fetch(`${API_BASE}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      if (!loginRes.ok) {
        const msg = await loginRes.text();
        throw new Error(msg || "Login failed");
      }

      const data = await loginRes.json();
      if (!data?.access_token) {
        throw new Error("Missing access token.");
      }
      onAuthSuccess(data.access_token);
      setSuccess("Login successful.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-shell" style={{ maxWidth: 560 }}>
      <div className="card">
        <h3 className="section-title">Welcome Back</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Sign in to access your lecture notes, mind maps, and error book.
        </p>

        <div className="tabs" style={{ marginBottom: 16 }}>
          <div
            className={`tab ${mode === "login" ? "active" : ""}`}
            onClick={() => {
              setMode("login");
              resetStatus();
            }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setMode("login");
            }}
          >
            Login
          </div>
          <div
            className={`tab ${mode === "register" ? "active" : ""}`}
            onClick={() => {
              setMode("register");
              resetStatus();
            }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setMode("register");
            }}
          >
            Register
          </div>
        </div>

        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <label className="muted" style={{ display: "block", marginBottom: 6 }}>
              Username
            </label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              autoComplete="username"
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          </div>
          <div>
            <label className="muted" style={{ display: "block", marginBottom: 6 }}>
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              autoComplete={mode === "register" ? "new-password" : "current-password"}
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          </div>
        </div>

        {mode === "register" && (
          <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>
            Password must be at least 8 characters and include letters + numbers.
          </div>
        )}

        <div style={{ marginTop: 16, display: "flex", gap: 10, alignItems: "center" }}>
          <button className="button primary" onClick={handleSubmit} disabled={loading}>
            {loading ? "Please wait..." : mode === "register" ? "Create account" : "Login"}
          </button>
          {error && <span className="status-pill error">{error}</span>}
          {success && <span className="status-pill success">{success}</span>}
        </div>
      </div>
    </div>
  );
}
