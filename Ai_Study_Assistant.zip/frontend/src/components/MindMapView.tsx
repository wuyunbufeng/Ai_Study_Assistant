import { useEffect, useMemo, useState } from "react";
import { Note } from "../types";
import { MindMapEntry } from "../types/mindmap";

const API_BASE = "http://127.0.0.1:8000";

type TreeNode = {
  id: string;
  text: string;
  children: TreeNode[];
};

type LayoutNode = {
  id: string;
  text: string;
  lines: string[];
  x: number;
  y: number;
  width: number;
  height: number;
  parentId?: string;
};

type Edge = {
  from: string;
  to: string;
};

type SavedNote = Note & { id: number; created_at: string };

const wrapText = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number) => {
  const paragraphs = text.split(/\r?\n/).map((line) => line.trim());
  const lines: string[] = [];
  paragraphs.forEach((paragraph) => {
    if (!paragraph) return;
    let current = "";
    for (const ch of paragraph) {
      const testLine = current + ch;
      if (ctx.measureText(testLine).width > maxWidth && current) {
        lines.push(current);
        current = ch;
      } else {
        current = testLine;
      }
    }
    if (current) lines.push(current);
  });
  return lines.length ? lines : [text];
};

const buildTree = (note: Note) => {
  let nodeId = 0;
  const createNode = (text: string): TreeNode => ({
    id: `node-${nodeId++}`,
    text,
    children: [],
  });

  const root = createNode(note.lecture_title || "Untitled Lecture");

  if (note.keywords && note.keywords.length > 0) {
    const keywordsNode = createNode("Keywords");
    note.keywords.forEach((keyword) => keywordsNode.children.push(createNode(keyword)));
    root.children.push(keywordsNode);
  }

  note.sections.forEach((section) => {
    const sectionNode = createNode(section.title);

    if (section.key_points && section.key_points.length > 0) {
      const keyPointsNode = createNode("Key Points");
      section.key_points.forEach((point) => keyPointsNode.children.push(createNode(point)));
      sectionNode.children.push(keyPointsNode);
    }

    if (section.examples && section.examples.length > 0) {
      const examplesNode = createNode("Examples");
      section.examples.forEach((example) => examplesNode.children.push(createNode(example)));
      sectionNode.children.push(examplesNode);
    }

    if (section.summary) {
      const summaryNode = createNode("Summary");
      summaryNode.children.push(createNode(section.summary));
      sectionNode.children.push(summaryNode);
    }

    root.children.push(sectionNode);
  });

  return root;
};

const renderNoteToPng = (note: Note) => {
  const root = buildTree(note);
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("Failed to create canvas context");
  }

  const paddingX = 16;
  const paddingY = 12;
  const nodeWidth = 220;
  const indent = 140;
  const verticalGap = 18;
  const lineHeight = 18;

  ctx.font = "14px Inter, Arial, sans-serif";

  const nodes: LayoutNode[] = [];
  const edges: Edge[] = [];
  let cursorY = 24;

  const walk = (node: TreeNode, depth: number, parentId?: string) => {
    const lines = wrapText(ctx, node.text, nodeWidth - paddingX * 2);
    const height = paddingY * 2 + lines.length * lineHeight;
    const x = 24 + depth * indent;
    const y = cursorY;
    nodes.push({ id: node.id, text: node.text, lines, x, y, width: nodeWidth, height, parentId });
    if (parentId) {
      edges.push({ from: parentId, to: node.id });
    }
    cursorY += height + verticalGap;
    node.children.forEach((child) => walk(child, depth + 1, node.id));
  };

  walk(root, 0);

  const maxX = nodes.reduce((max, node) => Math.max(max, node.x + node.width), 0);
  const maxY = nodes.reduce((max, node) => Math.max(max, node.y + node.height), 0);
  const width = maxX + 24;
  const height = maxY + 24;

  const scale = 2;
  canvas.width = width * scale;
  canvas.height = height * scale;
  ctx.scale(scale, scale);

  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = "#cfd6e6";
  ctx.lineWidth = 1;
  ctx.font = "14px Inter, Arial, sans-serif";

  edges.forEach((edge) => {
    const from = nodes.find((node) => node.id === edge.from);
    const to = nodes.find((node) => node.id === edge.to);
    if (!from || !to) return;
    const startX = from.x + from.width;
    const startY = from.y + from.height / 2;
    const endX = to.x;
    const endY = to.y + to.height / 2;
    const midX = (startX + endX) / 2;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(midX, startY);
    ctx.lineTo(midX, endY);
    ctx.lineTo(endX, endY);
    ctx.stroke();
  });

  nodes.forEach((node) => {
    ctx.fillStyle = "#f5f7ff";
    ctx.strokeStyle = "#d4d9e2";
    const radius = 10;
    const x = node.x;
    const y = node.y;
    const w = node.width;
    const h = node.height;

    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#1f2933";
    const textX = x + paddingX;
    let textY = y + paddingY + lineHeight;
    node.lines.forEach((line) => {
      ctx.fillText(line, textX, textY);
      textY += lineHeight;
    });
  });

  return canvas.toDataURL("image/png");
};

type Props = {
  note: Note | null;
  token: string;
  refreshKey: number;
  onNoteDeleted: (noteId: number) => void;
};

export default function MindMapView({ note, token, refreshKey, onNoteDeleted }: Props) {
  const [mindmaps, setMindmaps] = useState<MindMapEntry[]>([]);
  const [availableNotes, setAvailableNotes] = useState<SavedNote[]>([]);
  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState(false);
  const [notesLoading, setNotesLoading] = useState(false);
  const [status, setStatus] = useState("Idle");
  const [error, setError] = useState<string | null>(null);
  const [listError, setListError] = useState<string | null>(null);
  const [notesError, setNotesError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [imageLoading, setImageLoading] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [fullscreenOpen, setFullscreenOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<MindMapEntry | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [generateNoteId, setGenerateNoteId] = useState<number | null>(null);
  const [noteCache, setNoteCache] = useState<Record<number, Note>>({});

  const summaryMindmaps = useMemo(() => {
    const sorted = [...mindmaps].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
    const byNote = new Map<number, MindMapEntry>();
    for (const entry of sorted) {
      if (!byNote.has(entry.note_id)) {
        byNote.set(entry.note_id, entry);
      }
    }
    return Array.from(byNote.values());
  }, [mindmaps]);

  const selectedMindmap = useMemo(
    () => summaryMindmaps.find((entry) => entry.note_id === selectedNoteId) || null,
    [summaryMindmaps, selectedNoteId]
  );

  useEffect(() => {
    const fetchNotes = async () => {
      setNotesLoading(true);
      setNotesError(null);
      try {
        const res = await fetch(`${API_BASE}/api/notes`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || "Failed to load lectures.");
        }
        const data: SavedNote[] = await res.json();
        setAvailableNotes(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unexpected error";
        setNotesError(message);
      } finally {
        setNotesLoading(false);
      }
    };
    fetchNotes();
  }, [token, refreshKey]);

  useEffect(() => {
    if (availableNotes.length === 0) {
      setGenerateNoteId(null);
      return;
    }
    if (generateNoteId && availableNotes.some((entry) => entry.id === generateNoteId)) {
      return;
    }
    if (note?.id && availableNotes.some((entry) => entry.id === note.id)) {
      setGenerateNoteId(note.id);
      return;
    }
    setGenerateNoteId(availableNotes[0].id);
  }, [availableNotes, generateNoteId, note?.id]);

  useEffect(() => {
    const fetchMindmaps = async () => {
      setListError(null);
      try {
        const res = await fetch(`${API_BASE}/api/mindmap`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Failed to load mind maps.");
        const data: MindMapEntry[] = await res.json();
        setMindmaps(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unexpected error";
        setListError(message);
      }
    };
    fetchMindmaps();
  }, [token, refreshKey]);

  useEffect(() => {
    if (!summaryMindmaps.length) {
      setSelectedNoteId(null);
      return;
    }
    if (selectedNoteId && summaryMindmaps.some((entry) => entry.note_id === selectedNoteId)) {
      return;
    }
    setSelectedNoteId(summaryMindmaps[0].note_id);
  }, [summaryMindmaps, selectedNoteId]);

  useEffect(() => {
    if (!note?.id) return;
    if (summaryMindmaps.some((entry) => entry.note_id === note.id)) {
      setSelectedNoteId(note.id);
    }
  }, [note?.id, summaryMindmaps]);

  useEffect(() => {
    if (!selectedMindmap) {
      setSelectedNote(null);
      setImageUrl(null);
      setImageError(null);
      return;
    }

    const cached = noteCache[selectedMindmap.note_id];
    if (cached) {
      setSelectedNote(cached);
      return;
    }

    let cancelled = false;
    setImageLoading(true);
    setImageError(null);
    setImageUrl(null);
    setSelectedNote(null);

    const fetchNote = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/notes/${selectedMindmap.note_id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || "Failed to load lecture.");
        }
        const data: Note = await res.json();
        if (cancelled) return;
        setNoteCache((prev) => ({ ...prev, [selectedMindmap.note_id]: data }));
        setSelectedNote(data);
      } catch (err) {
        if (!cancelled) {
          const msg = err instanceof Error ? err.message : "Failed to load lecture.";
          setImageError(msg);
        }
      } finally {
        if (!cancelled) setImageLoading(false);
      }
    };

    fetchNote();

    return () => {
      cancelled = true;
    };
  }, [selectedMindmap, noteCache, token]);

  useEffect(() => {
    if (!selectedNote) return;
    let cancelled = false;
    setImageLoading(true);
    setImageError(null);
    setImageUrl(null);

    try {
      const png = renderNoteToPng(selectedNote);
      if (!cancelled) {
        setImageUrl(png);
      }
    } catch (err) {
      if (!cancelled) {
        const msg = err instanceof Error ? err.message : "Failed to render mind map";
        setImageError(msg);
      }
    } finally {
      if (!cancelled) setImageLoading(false);
    }

    return () => {
      cancelled = true;
    };
  }, [selectedNote]);

  useEffect(() => {
    setStatus("Idle");
    setError(null);
  }, [generateNoteId]);

  const handleGenerate = async () => {
    if (!generateNoteId) {
      setError("Select a saved lecture before generating a mind map.");
      return;
    }

    setLoading(true);
    setError(null);
    setStatus("Generating...");

    try {
      const response = await fetch(`${API_BASE}/api/mindmap/from_note`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ note_id: generateNoteId }),
      });

      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Failed to generate mind map");
      }

      const data: MindMapEntry = await response.json();
      setMindmaps((prev) => [data, ...prev.filter((item) => item.id !== data.id)]);
      setSelectedNoteId(data.note_id);
      setStatus("Ready");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setError(message);
      setStatus("Failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleteLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/notes/${deleteTarget.note_id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to delete lecture.");
      }
      setMindmaps((prev) => prev.filter((entry) => entry.note_id !== deleteTarget.note_id));
      setAvailableNotes((prev) => prev.filter((entry) => entry.id !== deleteTarget.note_id));
      setNoteCache((prev) => {
        const next = { ...prev };
        delete next[deleteTarget.note_id];
        return next;
      });
      if (generateNoteId === deleteTarget.note_id) {
        setGenerateNoteId(null);
      }
      if (selectedNoteId === deleteTarget.note_id) {
        setSelectedNote(null);
        setImageUrl(null);
        setSelectedNoteId(null);
      }
      onNoteDeleted(deleteTarget.note_id);
      setDeleteTarget(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setListError(message);
    } finally {
      setDeleteLoading(false);
    }
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString();
  };

  return (
    <div className="grid two-column">
      <div className="card">
        <h3 className="section-title">Mind Map</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Generate a mind map from the saved lecture note.
        </p>

        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <button
            className="button primary"
            onClick={handleGenerate}
            disabled={loading || !generateNoteId}
          >
            {loading ? "Generating..." : "Generate Mind Map"}
          </button>
          <div
            className={`status-pill ${status === "Ready" ? "success" : ""} ${
              status === "Failed" ? "error" : ""
            }`}
          >
            {status}
          </div>
          {error && <span className="status-pill error">{error}</span>}
        </div>

        <div style={{ marginTop: 16 }}>
          <div className="muted" style={{ fontSize: 13, marginBottom: 8 }}>
            Select lecture
          </div>
          <div
            style={{
              border: "1px solid #e3e7ee",
              borderRadius: 12,
              maxHeight: 220,
              overflow: "auto",
            }}
          >
            {notesLoading ? (
              <div className="empty-state" style={{ padding: 16 }}>
                Loading saved lectures...
              </div>
            ) : availableNotes.length === 0 ? (
              <div className="empty-state" style={{ padding: 16 }}>
                Save lecture notes first, then generate a mind map.
              </div>
            ) : (
              availableNotes.map((entry) => (
                <div
                  key={entry.id}
                  onClick={() => setGenerateNoteId(entry.id)}
                  style={{
                    padding: 12,
                    borderBottom: "1px solid #eef2fb",
                    cursor: "pointer",
                    background: generateNoteId === entry.id ? "#f5f7ff" : "transparent",
                  }}
                >
                  <div style={{ fontWeight: 700 }}>
                    {entry.lecture_title || "Untitled Lecture"}
                  </div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>
                    {formatDate(entry.created_at)}
                  </div>
                </div>
              ))
            )}
          </div>
          {notesError && (
            <div style={{ marginTop: 12 }}>
              <span className="status-pill error">{notesError}</span>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <h3 className="section-title">Mind Map History</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Select a lecture to preview its mind map.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 14 }}>
          <div
            style={{
              border: "1px solid #e3e7ee",
              borderRadius: 12,
              maxHeight: 420,
              overflow: "auto",
            }}
          >
            {summaryMindmaps.length === 0 ? (
              <div className="empty-state" style={{ padding: 20 }}>
                No saved mind maps yet.
              </div>
            ) : (
              summaryMindmaps.map((entry) => (
                <div
                  key={entry.note_id}
                  onClick={() => setSelectedNoteId(entry.note_id)}
                  style={{
                    padding: 12,
                    borderBottom: "1px solid #eef2fb",
                    cursor: "pointer",
                    background: selectedNoteId === entry.note_id ? "#f5f7ff" : "transparent",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 8,
                      alignItems: "center",
                    }}
                  >
                    <div style={{ fontWeight: 700 }}>
                      {entry.title || "Untitled Lecture"}
                    </div>
                    <button
                      className="button danger compact"
                      onClick={(event) => {
                        event.stopPropagation();
                        setDeleteTarget(entry);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>
                    {formatDate(entry.created_at)}
                  </div>
                </div>
              ))
            )}
          </div>

          <div
            style={{
              border: "1px solid #e3e7ee",
              borderRadius: 12,
              padding: 14,
              minHeight: 240,
              background: "#fbfcff",
            }}
          >
            {selectedMindmap ? (
              <>
                <div style={{ fontWeight: 700, marginBottom: 8 }}>
                  {selectedMindmap.title || "Untitled Lecture"}
                </div>
                {imageLoading && (
                  <div className="empty-state" style={{ padding: 20 }}>
                    Rendering mind map...
                  </div>
                )}
                {imageError && (
                  <div className="empty-state" style={{ padding: 20 }}>
                    {imageError}
                  </div>
                )}
                {imageUrl && !imageLoading && (
                  <img
                    src={imageUrl}
                    alt="mindmap"
                    onClick={() => setFullscreenOpen(true)}
                    style={{
                      width: "100%",
                      borderRadius: 12,
                      border: "1px solid #e3e7ee",
                      cursor: "zoom-in",
                      background: "#fff",
                    }}
                  />
                )}
                {imageUrl && (
                  <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>
                    Click to preview full size, then right-click to save.
                  </div>
                )}
              </>
            ) : (
              <div className="empty-state" style={{ padding: 20 }}>
                Select a lecture from the list.
              </div>
            )}
          </div>
        </div>
        {listError && (
          <div style={{ marginTop: 12 }}>
            <span className="status-pill error">{listError}</span>
          </div>
        )}
      </div>

      {fullscreenOpen && imageUrl && (
        <div
          onClick={() => setFullscreenOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 24,
            cursor: "zoom-out",
          }}
        >
          <img
            src={imageUrl}
            alt="mindmap-full"
            style={{
              maxWidth: "96vw",
              maxHeight: "96vh",
              borderRadius: 12,
              border: "1px solid #e3e7ee",
              background: "#fff",
            }}
          />
        </div>
      )}

      {deleteTarget && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div className="card modal-card" style={{ width: "min(420px, 92vw)" }}>
            <h3 className="section-title">Delete Lecture</h3>
            <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
              Delete "{deleteTarget.title || "Untitled Lecture"}"? This will also remove its mind
              map.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="button secondary" onClick={() => setDeleteTarget(null)}>
                Cancel
              </button>
              <button className="button danger" onClick={handleDelete} disabled={deleteLoading}>
                {deleteLoading ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
