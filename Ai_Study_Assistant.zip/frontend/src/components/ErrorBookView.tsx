import { useEffect, useMemo, useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeKatex from "rehype-katex";
import remarkMath from "remark-math";
import { WrongQuestion } from "../types/errorBook";

const API_BASE = "http://127.0.0.1:8000";
const SUBJECT_ALIASES: Record<string, string> = {
  english: "\u82f1\u8bed",
  "english language": "\u82f1\u8bed",
  math: "\u6570\u5b66",
  maths: "\u6570\u5b66",
  mathematics: "\u6570\u5b66",
  chinese: "\u8bed\u6587",
  "chinese language": "\u8bed\u6587",
  physics: "\u7269\u7406",
  chemistry: "\u5316\u5b66",
  biology: "\u751f\u7269",
  history: "\u5386\u53f2",
  geography: "\u5730\u7406",
  politics: "\u653f\u6cbb",
  science: "\u79d1\u5b66",
};
const UI_TEXT = {
  subjectLabel: "Subject",
  knowledgeLabel: "Knowledge Point",
  subjectPlaceholder: "e.g. Math / English",
  knowledgePlaceholder: "e.g. Quadratic functions / Verb tenses",
  subjectOnlyChinese: "Subject must be in Chinese.",
  knowledgeOnlyChinese: "Knowledge point must be in Chinese.",
  uncategorized: "Uncategorized",
  subjectDescription: "Browse errors by subject. Click a subject to view details.",
  noQuestions: "No questions yet.",
  subjectModalDescription: "Questions and details for this subject.",
  knowledgeMissing: "Knowledge point not set",
  selectFromLeft: "Select a question on the left to view details.",
  back: "Back",
};
const DOT = "\u00b7";
const CJK_INPUT_RE = /[\u4e00-\u9fff]/;
const LATIN_INPUT_RE = /[A-Za-z]/;

const normalizeSubjectLabel = (subject?: string | null) => {
  const raw = (subject ?? "").trim();
  if (!raw) return UI_TEXT.uncategorized;
  if (CJK_INPUT_RE.test(raw)) return raw;
  const rawLower = raw.toLowerCase();
  for (const [key, value] of Object.entries(SUBJECT_ALIASES)) {
    if (rawLower === key || rawLower.includes(key)) return value;
  }
  return UI_TEXT.uncategorized;
};

const normalizeSubjectInput = (value: string) => {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (CJK_INPUT_RE.test(trimmed)) return trimmed;
  const trimmedLower = trimmed.toLowerCase();
  for (const [key, val] of Object.entries(SUBJECT_ALIASES)) {
    if (trimmedLower === key || trimmedLower.includes(key)) return val;
  }
  return trimmed;
};

const containsLatin = (value: string) => LATIN_INPUT_RE.test(value);

type Props = {
  token: string;
};

const resolveImageUrl = (url: string | null, path: string | null) => {
  if (url) {
    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    return `${API_BASE}${url.startsWith("/") ? "" : "/"}${url}`;
  }
  if (path) {
    return `${API_BASE}/static/${path}`;
  }
  return null;
};

export default function ErrorBookView({ token }: Props) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisModalOpen, setAnalysisModalOpen] = useState(false);
  const [subjectModalOpen, setSubjectModalOpen] = useState(false);
  const [activeSubject, setActiveSubject] = useState<string | null>(null);
  const [subjectOrder, setSubjectOrder] = useState<string[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<WrongQuestion | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [editTargetId, setEditTargetId] = useState<number | null>(null);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [metadataLoading, setMetadataLoading] = useState(false);
  const [metadataError, setMetadataError] = useState<string | null>(null);
  const [imagePath, setImagePath] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [ocrRawText, setOcrRawText] = useState<string>("");
  const [ocrPreview, setOcrPreview] = useState<string>("");
  const [structuredText, setStructuredText] = useState<string>("");
  const [subject, setSubject] = useState<string>("");
  const [knowledgePoint, setKnowledgePoint] = useState<string>("");
  const [note, setNote] = useState<string>("");
  const [questions, setQuestions] = useState<WrongQuestion[]>([]);
  const [selectedQuestionId, setSelectedQuestionId] = useState<number | null>(null);

  const selectedQuestion = useMemo(
    () => questions.find((q) => q.id === selectedQuestionId) || null,
    [questions, selectedQuestionId]
  );
  const isEditing = editTargetId !== null;
  const analysisText = selectedQuestion?.analysis?.trim() || "";
  const analysisErrorMessage = selectedQuestion?.analysis_error?.trim() || "";
  const previewMarkdown = useMemo(() => {
    const source = ocrPreview || "OCR results will appear here.";
    return source.replace(/\n/g, "  \n");
  }, [ocrPreview]);
  const analysisMarkdown = useMemo(() => {
    const source = analysisText || "Analysis pending. Please wait or click Regenerate analysis.";
    return source.replace(/\n/g, "  \n");
  }, [analysisText]);
  const backButtonStyle = { minWidth: 96 };
  const subjectValidationMessage = useMemo(() => {
    if (!subject.trim()) return null;
    return containsLatin(subject) ? UI_TEXT.subjectOnlyChinese : null;
  }, [subject]);
  const knowledgeValidationMessage = useMemo(() => {
    if (!knowledgePoint.trim()) return null;
    return containsLatin(knowledgePoint) ? UI_TEXT.knowledgeOnlyChinese : null;
  }, [knowledgePoint]);
  const inputValidationMessage = subjectValidationMessage || knowledgeValidationMessage;
  const getInputValidationError = (nextSubject: string, nextKnowledgePoint: string) => {
    if (nextSubject.trim() && containsLatin(nextSubject)) return UI_TEXT.subjectOnlyChinese;
    if (nextKnowledgePoint.trim() && containsLatin(nextKnowledgePoint))
      return UI_TEXT.knowledgeOnlyChinese;
    return null;
  };
  const activeSubjectQuestions = useMemo(() => {
    if (!activeSubject) return [];
    return questions.filter(
      (question) => normalizeSubjectLabel(question.subject) === activeSubject
    );
  }, [questions, activeSubject]);

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/errors`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Failed to load error book");
        const data: WrongQuestion[] = await res.json();
        setQuestions(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchQuestions();
  }, [token]);

  useEffect(() => {
    const subjectsInData = new Set(
      questions.map((question) => normalizeSubjectLabel(question.subject))
    );
    setSubjectOrder((prev) => {
      const next = prev.filter((label) => subjectsInData.has(label));
      const seen = new Set(next);
      for (const question of questions) {
        const label = normalizeSubjectLabel(question.subject);
        if (!seen.has(label)) {
          seen.add(label);
          next.push(label);
        }
      }
      return next;
    });
  }, [questions]);

  useEffect(() => {
    if (!subjectModalOpen || !activeSubject) return;
    if (activeSubjectQuestions.length === 0) {
      setSubjectModalOpen(false);
      setActiveSubject(null);
      return;
    }
    if (
      !selectedQuestionId ||
      !activeSubjectQuestions.some((q) => q.id === selectedQuestionId)
    ) {
      setSelectedQuestionId(activeSubjectQuestions[0].id);
    }
  }, [subjectModalOpen, activeSubject, activeSubjectQuestions, selectedQuestionId]);

  const upsertQuestion = (updated: WrongQuestion) => {
    setQuestions((prev) => {
      const exists = prev.some((q) => q.id === updated.id);
      if (!exists) {
        return [updated, ...prev];
      }
      return prev.map((q) => (q.id === updated.id ? { ...q, ...updated } : q));
    });
  };

  const fetchQuestionById = async (id: number) => {
    const res = await fetch(`${API_BASE}/api/errors/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error("Failed to load question details");
    const data: WrongQuestion = await res.json();
    upsertQuestion(data);
    return data;
  };

  useEffect(() => {
    if (!selectedQuestionId) return;
    setAnalysisError(null);
    fetchQuestionById(selectedQuestionId).catch((err) => {
      const msg = err instanceof Error ? err.message : "Failed to load analysis";
      setAnalysisError(msg);
    });
  }, [selectedQuestionId, token]);

  useEffect(() => {
    if (!selectedQuestionId) return;
    if (selectedQuestion?.analysis?.trim()) return;
    let cancelled = false;
    let attempts = 0;

    const poll = async () => {
      while (!cancelled && attempts < 5) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
        if (cancelled) return;
        try {
          const data = await fetchQuestionById(selectedQuestionId);
          if (data.analysis && data.analysis.trim()) {
            return;
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Failed to refresh analysis";
          setAnalysisError(msg);
        }
        attempts += 1;
      }
    };

    poll();
    return () => {
      cancelled = true;
    };
  }, [selectedQuestionId, selectedQuestion?.analysis, token]);

  const handleFileChange = (file: File | null) => {
    if (isEditing) return;
    setSelectedFile(file);
    setOcrError(null);
    setMetadataError(null);
    setImagePath(null);
    setImageUrl(null);
    setOcrRawText("");
    setOcrPreview("");
    setStructuredText("");
  };

  const handleOcr = async () => {
    if (isEditing) {
      setOcrError("Editing a saved question. Cancel edit to run OCR.");
      return;
    }
    if (!selectedFile) {
      setOcrError("Please select an image file first.");
      return;
    }
    setOcrLoading(true);
    setOcrError(null);
    try {
      const formData = new FormData();
      formData.append("file", selectedFile);
      const res = await fetch(`${API_BASE}/api/errors/ocr`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "OCR failed");
      }
      const data = await res.json();
      setImagePath(data.image_path);
      setImageUrl(resolveImageUrl(data.image_url || null, data.image_path || null));
      const structured = (data.structured_text || "").trim();
      const preview = structured || data.raw_text || "";
      setOcrRawText(data.raw_text || "");
      setStructuredText(structured);
      setOcrPreview(preview);
      if (preview.trim()) {
        void inferMetadata(preview);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected OCR error";
      setOcrError(msg);
      setImagePath(null);
      setImageUrl(null);
      setOcrRawText("");
      setOcrPreview("");
      setStructuredText("");
    } finally {
      setOcrLoading(false);
    }
  };

  const handleSave = async () => {
    if (isEditing) return;
    if (!imagePath || !ocrPreview.trim()) {
      setSaveError("Missing OCR result. Please run OCR first.");
      return;
    }
    const normalizedSubject = normalizeSubjectInput(subject);
    const normalizedKnowledgePoint = knowledgePoint.trim();
    const validationError = getInputValidationError(
      normalizedSubject,
      normalizedKnowledgePoint
    );
    if (validationError) {
      setSaveError(validationError);
      return;
    }
    setSaveLoading(true);
    setSaveError(null);
    try {
      const payload = {
        image_path: imagePath,
        raw_text: ocrRawText || ocrPreview,
        structured_text: structuredText || null,
        subject: normalizedSubject,
        knowledge_point: normalizedKnowledgePoint,
        note,
      };
      const res = await fetch(`${API_BASE}/api/errors/save`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to save question");
      }
      const saved: WrongQuestion = await res.json();
      setQuestions((prev) => [saved, ...prev]);
      setSelectedQuestionId(saved.id);
      // Clear transient inputs
      setSelectedFile(null);
      setImagePath(null);
      setImageUrl(null);
      setOcrRawText("");
      setOcrPreview("");
      setStructuredText("");
      setNote("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected save error";
      setSaveError(msg);
    } finally {
      setSaveLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleteLoading(true);
    setDeleteError(null);
    try {
      const res = await fetch(`${API_BASE}/api/errors/${deleteTarget.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to delete question.");
      }
      setQuestions((prev) => prev.filter((entry) => entry.id !== deleteTarget.id));
      if (selectedQuestionId === deleteTarget.id) {
        setSelectedQuestionId(null);
      }
      setDeleteTarget(null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected delete error";
      setDeleteError(msg);
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleRegenerateAnalysis = async () => {
    if (!selectedQuestionId) return;
    setAnalysisLoading(true);
    setAnalysisError(null);
    try {
      const res = await fetch(
        `${API_BASE}/api/errors/${selectedQuestionId}/analysis?force=true`,
        {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to regenerate analysis");
      }
      setQuestions((prev) =>
        prev.map((q) => (q.id === selectedQuestionId ? { ...q, analysis: "" } : q))
      );
      await fetchQuestionById(selectedQuestionId);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected analysis error";
      setAnalysisError(msg);
    } finally {
      setAnalysisLoading(false);
    }
  };

  const handleEditStart = () => {
    if (!selectedQuestion) return;
    setEditTargetId(selectedQuestion.id);
    setEditError(null);
    setSubject(normalizeSubjectInput(selectedQuestion.subject || ""));
    setKnowledgePoint(selectedQuestion.knowledge_point || "");
    setNote(selectedQuestion.note || "");
  };

  const handleEditCancel = () => {
    setEditTargetId(null);
    setEditError(null);
    setSubject("");
    setKnowledgePoint("");
    setNote("");
  };

  const handleUpdate = async () => {
    if (!editTargetId) return;
    const normalizedSubject = normalizeSubjectInput(subject);
    const normalizedKnowledgePoint = knowledgePoint.trim();
    const validationError = getInputValidationError(
      normalizedSubject,
      normalizedKnowledgePoint
    );
    if (validationError) {
      setEditError(validationError);
      return;
    }
    setEditLoading(true);
    setEditError(null);
    try {
      const payload = {
        subject: normalizedSubject.trim() || null,
        knowledge_point: normalizedKnowledgePoint || null,
        note: note.trim() || null,
      };
      const res = await fetch(`${API_BASE}/api/errors/${editTargetId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to update question.");
      }
      const updated: WrongQuestion = await res.json();
      upsertQuestion(updated);
      setSelectedQuestionId(updated.id);
      handleEditCancel();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected edit error";
      setEditError(msg);
    } finally {
      setEditLoading(false);
    }
  };

  const openSubjectModal = (label: string) => {
    setActiveSubject(label);
    setSubjectModalOpen(true);
    const subjectQuestions = questions.filter(
      (question) => normalizeSubjectLabel(question.subject) === label
    );
    const hasSelected =
      selectedQuestionId && subjectQuestions.some((q) => q.id === selectedQuestionId);
    if (!hasSelected) {
      setSelectedQuestionId(subjectQuestions[0]?.id ?? null);
    }
  };

  const inferMetadata = async (text: string) => {
    if (!text.trim() || isEditing) return;
    setMetadataLoading(true);
    setMetadataError(null);
    try {
      const res = await fetch(`${API_BASE}/api/errors/metadata`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to infer metadata.");
      }
      const data = (await res.json()) as {
        subject?: string;
        knowledge_point?: string;
        error?: string;
      };
      if (data.error) {
        setMetadataError(data.error);
      }
      const nextSubject = (data.subject || "").trim();
      const nextKnowledge = (data.knowledge_point || "").trim();
      if (nextSubject) {
        setSubject(normalizeSubjectInput(nextSubject));
      }
      if (nextKnowledge) {
        setKnowledgePoint(nextKnowledge);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unexpected metadata error";
      setMetadataError(msg);
    } finally {
      setMetadataLoading(false);
    }
  };

  useEffect(() => {
    setAnalysisModalOpen(false);
    if (editTargetId && editTargetId !== selectedQuestionId) {
      setEditTargetId(null);
      setEditError(null);
      setSubject("");
      setKnowledgePoint("");
      setNote("");
    }
  }, [selectedQuestionId, editTargetId]);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString();
  };

  return (
    <div className="grid two-column">
      <div className="card">
        <h3 className="section-title">Upload & OCR</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          Upload a question image, auto-recognize the text, then add subject and knowledge points before
          saving.
        </p>
        {isEditing && (
          <div
            style={{
              background: "#fff4e5",
              border: "1px solid #f3c18f",
              color: "#8a4b0f",
              padding: "10px 12px",
              borderRadius: 10,
              marginBottom: 12,
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            Editing selected question metadata. OCR upload is disabled.
          </div>
        )}

        <div
          className="upload-dropzone"
          onClick={() => document.getElementById("error-upload")?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") document.getElementById("error-upload")?.click();
          }}
        >
          <input
            id="error-upload"
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            disabled={isEditing}
            onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
          />
          <div style={{ fontWeight: 700, color: "#2f4ea6", marginBottom: 8 }}>
            Drag an image here or click to choose
          </div>
          <div className="muted">
            {selectedFile
              ? `Selected: ${selectedFile.name}`
              : "Supports common image formats (png, jpg, jpeg)"}
          </div>
        </div>

        <div style={{ marginTop: 16, display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button
            className="button secondary"
            onClick={handleOcr}
            disabled={ocrLoading || isEditing}
          >
            {ocrLoading ? "Recognizing..." : "Recognize question"}
          </button>
          {isEditing ? (
            <>
              <button className="button primary" onClick={handleUpdate} disabled={editLoading}>
                {editLoading ? "Updating..." : "Update Question"}
              </button>
              <button className="button secondary" onClick={handleEditCancel}>
                Cancel Edit
              </button>
            </>
          ) : (
            <button className="button primary" onClick={handleSave} disabled={saveLoading}>
              {saveLoading ? "Saving..." : "Save to Error Book"}
            </button>
          )}
          {ocrError && <span className="status-pill error">{ocrError}</span>}
          {saveError && <span className="status-pill error">{saveError}</span>}
          {editError && <span className="status-pill error">{editError}</span>}
          {metadataLoading && <span className="status-pill">Inferring subject...</span>}
          {metadataError && <span className="status-pill error">{metadataError}</span>}
        </div>

        {imageUrl && (
          <div style={{ marginTop: 16 }}>
            <div className="muted" style={{ marginBottom: 8 }}>
              Preview
            </div>
            <img
              src={imageUrl}
              alt="upload-preview"
              style={{ width: "100%", borderRadius: 12, border: "1px solid #e3e7ee" }}
            />
          </div>
        )}

        <div style={{ marginTop: 16 }}>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            OCR Preview
          </label>
          <div
            style={{
              width: "100%",
              minHeight: 120,
              borderRadius: 10,
              border: "1px solid #d4d9e2",
              padding: 12,
              fontSize: 14,
              fontFamily: "inherit",
              background: "#fff",
              color: "#0f172a",
            }}
          >
            <ReactMarkdown
              remarkPlugins={[remarkMath]}
              rehypePlugins={[rehypeKatex]}
              components={{
                p: ({ node, ...props }) => <p style={{ margin: 0 }} {...props} />,
              }}
            >
              {previewMarkdown}
            </ReactMarkdown>
          </div>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 12, gridTemplateColumns: "1fr 1fr" }}>
          <div>
            <label className="muted" style={{ display: "block", marginBottom: 6 }}>
              {UI_TEXT.subjectLabel}
            </label>
            <input
              value={subject}
              onChange={(e) => setSubject(normalizeSubjectInput(e.target.value))}
              placeholder={UI_TEXT.subjectPlaceholder}
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          </div>
          <div>
            <label className="muted" style={{ display: "block", marginBottom: 6 }}>
              {UI_TEXT.knowledgeLabel}
            </label>
            <input
              value={knowledgePoint}
              onChange={(e) => setKnowledgePoint(e.target.value)}
              placeholder={UI_TEXT.knowledgePlaceholder}
              style={{
                width: "100%",
                borderRadius: 10,
                border: "1px solid #d4d9e2",
                padding: 10,
              }}
            />
          </div>
        </div>
        {inputValidationMessage && (
          <div style={{ marginTop: 8 }}>
            <span className="status-pill error">{inputValidationMessage}</span>
          </div>
        )}

        <div style={{ marginTop: 12 }}>
          <label className="muted" style={{ display: "block", marginBottom: 6 }}>
            Notes
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Optional: add your solution idea or common pitfalls."
            style={{
              width: "100%",
              minHeight: 80,
              borderRadius: 10,
              border: "1px solid #d4d9e2",
              padding: 12,
              fontSize: 14,
              fontFamily: "inherit",
            }}
          />
        </div>
      </div>

      <div className="card">
        <h3 className="section-title">Error Book</h3>
        <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
          {UI_TEXT.subjectDescription}
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
            gap: 12,
            justifyItems: "center",
          }}
        >
          {subjectOrder.length === 0 ? (
            <div className="empty-state" style={{ padding: 20, gridColumn: "1 / -1" }}>
              {UI_TEXT.noQuestions}
            </div>
          ) : (
            subjectOrder.map((label) => (
              <button
                key={label}
                type="button"
                onClick={() => openSubjectModal(label)}
                style={{
                  border: "1px solid #e3e7ee",
                  borderRadius: 14,
                  background: "#eef3ff",
                  padding: 12,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  textAlign: "center",
                  fontWeight: 700,
                  color: "#1f2933",
                  cursor: "pointer",
                  width: "100%",
                  maxWidth: 120,
                  aspectRatio: "1 / 1",
                }}
              >
                {label}
              </button>
            ))
          )}
        </div>

        {deleteError && (
          <div style={{ marginTop: 12 }}>
            <span className="status-pill error">{deleteError}</span>
          </div>
        )}
      </div>

      {subjectModalOpen && activeSubject && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 900,
            padding: 16,
          }}
        >
          <div className="card modal-card" style={{ width: "min(980px, 96vw)" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 12,
                flexWrap: "wrap",
              }}
            >
              <div>
                <h3 className="section-title" style={{ marginBottom: 4 }}>
                  {activeSubject}
                </h3>
                <div className="muted" style={{ fontSize: 13 }}>
                  {UI_TEXT.subjectModalDescription}
                </div>
              </div>
              <button
                className="button secondary"
                style={backButtonStyle}
                onClick={() => {
                  setSubjectModalOpen(false);
                  setActiveSubject(null);
                }}
              >
                {UI_TEXT.back}
              </button>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1.2fr",
                gap: 14,
                marginTop: 14,
              }}
            >
              <div
                style={{
                  border: "1px solid #e3e7ee",
                  borderRadius: 12,
                  maxHeight: 460,
                  overflow: "auto",
                }}
              >
                {activeSubjectQuestions.length === 0 ? (
                  <div className="empty-state" style={{ padding: 20 }}>
                    {UI_TEXT.noQuestions}
                  </div>
                ) : (
                  activeSubjectQuestions.map((q) => (
                    <div
                      key={q.id}
                      onClick={() => setSelectedQuestionId(q.id)}
                      style={{
                        padding: 12,
                        borderBottom: "1px solid #eef2fb",
                        cursor: "pointer",
                        background: selectedQuestionId === q.id ? "#f5f7ff" : "transparent",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          gap: 8,
                          alignItems: "center",
                        }}
                      >
                        <div style={{ fontWeight: 700, marginBottom: 4, flex: 1, minWidth: 0 }}>
                          {normalizeSubjectLabel(q.subject)} {DOT}{" "}
                          {q.knowledge_point || UI_TEXT.knowledgeMissing}
                        </div>
                        <button
                          className="button danger compact"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeleteError(null);
                            setDeleteTarget(q);
                          }}
                        >
                          Delete
                        </button>
                      </div>
                      <div className="muted" style={{ fontSize: 12, marginBottom: 4 }}>
                        {formatDate(q.created_at)}
                      </div>
                      <div className="muted" style={{ fontSize: 13 }}>
                        <ReactMarkdown
                          remarkPlugins={[remarkMath]}
                          rehypePlugins={[rehypeKatex]}
                          components={{
                            p: ({ node, ...props }) => <p style={{ margin: 0 }} {...props} />,
                          }}
                        >
                          {(q.structured_text || q.raw_text || "").replace(/\n/g, "  \n")}
                        </ReactMarkdown>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div
                style={{
                  border: "1px solid #e3e7ee",
                  borderRadius: 12,
                  padding: 14,
                  minHeight: 240,
                  background: "#fbfcff",
                }}
              >
                {selectedQuestion ? (
                  <>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: 12,
                        flexWrap: "wrap",
                      }}
                    >
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 16 }}>
                          {normalizeSubjectLabel(selectedQuestion.subject)} {DOT}{" "}
                          {selectedQuestion.knowledge_point || UI_TEXT.knowledgeMissing}
                        </div>
                        <div className="muted" style={{ fontSize: 12 }}>
                          {formatDate(selectedQuestion.created_at)}
                        </div>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          gap: 10,
                          alignItems: "center",
                          flexWrap: "wrap",
                        }}
                      >
                        <button
                          className="button primary"
                          onClick={handleEditStart}
                          disabled={isEditing}
                        >
                          Edit
                        </button>
                        <button
                          className="button secondary"
                          onClick={handleRegenerateAnalysis}
                          disabled={analysisLoading}
                        >
                          {analysisLoading ? "Analyzing..." : "Regenerate analysis"}
                        </button>
                        {analysisError && <span className="status-pill error">{analysisError}</span>}
                      </div>
                    </div>
                    {selectedQuestion.image_path && (
                      <img
                        src={
                          resolveImageUrl(
                            selectedQuestion.image_url || null,
                            selectedQuestion.image_path || null
                          ) || ""
                        }
                        alt="question"
                        style={{
                          width: "100%",
                          borderRadius: 10,
                          border: "1px solid #e3e7ee",
                          marginTop: 10,
                        }}
                      />
                    )}
                    <div style={{ marginTop: 10 }}>
                      <div className="muted" style={{ marginBottom: 6 }}>
                        AI Analysis
                      </div>
                      <div
                        style={{
                          display: "flex",
                          gap: 10,
                          alignItems: "center",
                          flexWrap: "wrap",
                        }}
                      >
                        <button
                          className="button secondary"
                          onClick={() => setAnalysisModalOpen(true)}
                        >
                          {analysisLoading ? "Analyzing..." : "View analysis"}
                        </button>
                        {analysisErrorMessage && (
                          <span className="status-pill error">{analysisErrorMessage}</span>
                        )}
                      </div>
                    </div>
                    {selectedQuestion.note && (
                      <div style={{ marginTop: 10 }}>
                        <div className="muted" style={{ marginBottom: 6 }}>
                          Notes
                        </div>
                        <div
                          style={{
                            background: "#fff",
                            border: "1px solid #e3e7ee",
                            borderRadius: 10,
                            padding: 12,
                            minHeight: 60,
                            whiteSpace: "pre-wrap",
                          }}
                        >
                          {selectedQuestion.note}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="empty-state" style={{ padding: 20 }}>
                    {UI_TEXT.selectFromLeft}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {deleteTarget && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div className="card" style={{ width: "min(420px, 92vw)" }}>
            <h3 className="section-title">Delete Question</h3>
            <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
              Delete this question? This will also remove its image and analysis.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="button secondary" onClick={() => setDeleteTarget(null)}>
                Cancel
              </button>
              <button className="button danger" onClick={handleDelete} disabled={deleteLoading}>
                {deleteLoading ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}

      {analysisModalOpen && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1100,
            padding: 16,
          }}
        >
          <div className="card modal-card" style={{ width: "min(720px, 92vw)" }}>
            <h3 className="section-title">AI Analysis</h3>
            <div
              style={{
                background: "#0f172a",
                color: "#e5e7eb",
                borderRadius: 10,
                padding: 12,
                maxHeight: "70vh",
                overflow: "auto",
                fontSize: 14,
              }}
            >
              <ReactMarkdown
                remarkPlugins={[remarkMath]}
                rehypePlugins={[rehypeKatex]}
                components={{
                  p: ({ node, ...props }) => <p style={{ margin: 0 }} {...props} />,
                }}
              >
                {analysisLoading ? "Analyzing..." : analysisMarkdown}
              </ReactMarkdown>
            </div>
            {analysisErrorMessage && (
              <div style={{ marginTop: 10 }}>
                <span className="status-pill error">{analysisErrorMessage}</span>
              </div>
            )}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
              <button
                className="button secondary"
                style={backButtonStyle}
                onClick={() => setAnalysisModalOpen(false)}
              >
                {UI_TEXT.back}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
