import { useEffect, useRef, useState } from "react";

type Props = {
  selectedFile: File | null;
  selectedFileInfo: string | null;
  previewAudioUrl?: string | null;
  previewAudioLabel?: string | null;
  onFileSelect: (file: File | null) => void;
  onGenerate: () => void;
  onClearFile: () => void;
  loading: boolean;
  status: string;
  error: string | null;
};

export default function UploadCard({
  selectedFile,
  selectedFileInfo,
  previewAudioUrl = null,
  previewAudioLabel = null,
  onFileSelect,
  onGenerate,
  onClearFile,
  loading,
  status,
  error,
}: Props) {
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [localAudioUrl, setLocalAudioUrl] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [seekTime, setSeekTime] = useState(0);
  const [isSeeking, setIsSeeking] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    onFileSelect(files[0]);
  };

  useEffect(() => {
    if (!selectedFile) {
      setLocalAudioUrl(null);
      return;
    }
    const url = URL.createObjectURL(selectedFile);
    setLocalAudioUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [selectedFile]);

  const activeAudioUrl = previewAudioUrl ?? localAudioUrl;
  const activeLabel = previewAudioLabel ?? selectedFileInfo;

  useEffect(() => {
    if (!activeAudioUrl) {
      setDuration(0);
      setCurrentTime(0);
      setSeekTime(0);
      setIsPlaying(false);
      setAudioError(null);
      return;
    }
    setDuration(0);
    setCurrentTime(0);
    setSeekTime(0);
    setIsPlaying(false);
    setAudioError(null);
  }, [activeAudioUrl]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    audio.currentTime = 0;
  }, [activeAudioUrl]);

  const formatTime = (value: number) => {
    const totalSeconds = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  };

  const handlePlayPause = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      try {
        await audio.play();
      } catch (err) {
        setAudioError("Unable to play this audio file.");
      }
    } else {
      audio.pause();
    }
  };

  const handleSkip = (delta: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const total = Number.isFinite(audio.duration) ? audio.duration : duration;
    const next = Math.min(Math.max(0, audio.currentTime + delta), total || 0);
    audio.currentTime = next;
    setCurrentTime(next);
    setSeekTime(next);
  };

  const handleSeekChange = (value: number) => {
    const audio = audioRef.current;
    setSeekTime(value);
    setCurrentTime(value);
    if (audio) {
      audio.currentTime = value;
    }
  };

  return (
    <div className="card">
      <h3 className="section-title">Upload Recording</h3>
      <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
        Drag & drop classroom audio or choose a file. Supported: wav, mp3, m4a, webm.
      </p>

      <div
        className={`upload-dropzone ${isDragOver ? "dragover" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="audio/*"
          style={{ display: "none" }}
          onChange={(e) => handleFiles(e.target.files)}
        />
        <div style={{ fontWeight: 700, color: "#2f4ea6", marginBottom: 8 }}>Drop your audio here</div>
        <div className="muted">or click to browse files</div>
      </div>

      <div style={{ marginTop: 16, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <button className="button secondary" onClick={onClearFile} disabled={loading}>
          Clear file
        </button>
        <button className="button primary" onClick={onGenerate} disabled={loading}>
          {loading ? "Generating..." : "Generate Notes"}
        </button>
        <div className={`status-pill ${status.includes("completed") ? "success" : ""} ${status.includes("Failed") ? "error" : ""}`}>
          {status}
        </div>
      </div>

      {activeLabel ? (
        <div style={{ marginTop: 12, fontWeight: 600 }}>{activeLabel}</div>
      ) : (
        <div style={{ marginTop: 12 }} className="muted">
          No file selected
        </div>
      )}

      {activeAudioUrl && (
        <div className="audio-player">
          <audio
            ref={audioRef}
            src={activeAudioUrl}
            preload="metadata"
            onLoadedMetadata={() => {
              const audio = audioRef.current;
              if (!audio || !Number.isFinite(audio.duration)) return;
              setDuration(audio.duration);
            }}
            onTimeUpdate={() => {
              const audio = audioRef.current;
              if (!audio || isSeeking) return;
              setCurrentTime(audio.currentTime);
            }}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            onError={() => setAudioError("Unable to load audio preview.")}
          />
          <div className="audio-timeline">
            <span className="audio-time">{formatTime(isSeeking ? seekTime : currentTime)}</span>
            <input
              className="audio-range"
              type="range"
              min={0}
              max={duration || 0}
              step={0.1}
              value={Math.min(isSeeking ? seekTime : currentTime, duration || 0)}
              onChange={(event) => handleSeekChange(Number(event.target.value))}
              onPointerDown={() => setIsSeeking(true)}
              onPointerUp={() => setIsSeeking(false)}
              onPointerCancel={() => setIsSeeking(false)}
              aria-label="Audio progress"
            />
            <span className="audio-time">{formatTime(duration)}</span>
          </div>
          <div className="audio-controls">
            <button
              className="button secondary compact"
              onClick={() => handleSkip(-5)}
              disabled={!activeAudioUrl}
              aria-label="Back 5 seconds"
            >
              -5s
            </button>
            <button
              className="button primary compact"
              onClick={handlePlayPause}
              disabled={!activeAudioUrl}
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? "Pause" : "Play"}
            </button>
            <button
              className="button secondary compact"
              onClick={() => handleSkip(5)}
              disabled={!activeAudioUrl}
              aria-label="Forward 5 seconds"
            >
              +5s
            </button>
          </div>
        </div>
      )}

      {audioError && (
        <div style={{ marginTop: 12, color: "#c03540", fontWeight: 600 }}>
          {audioError}
        </div>
      )}

      {error && (
        <div style={{ marginTop: 12, color: "#c03540", fontWeight: 600 }}>
          {error}
        </div>
      )}
    </div>
  );
}
