import { useEffect, useMemo, useState } from "react";
import { Note } from "../types";

const API_BASE = "http://127.0.0.1:8000";

type Props = {
  note: Note | null;
  token: string;
  refreshKey: number;
  onSelectNote: (note: Note) => void;
  onNoteDeleted: (noteId: number) => void;
};

type SavedNote = Note & { id: number; created_at: string };

export default function NotesView({ note, token, refreshKey, onSelectNote, onNoteDeleted }: Props) {
  const [notes, setNotes] = useState<SavedNote[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SavedNote | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [structuredOpen, setStructuredOpen] = useState(false);
  const [transcriptOpen, setTranscriptOpen] = useState(false);

  useEffect(() => {
    const fetchNotes = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${API_BASE}/api/notes`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || "Failed to load notes.");
        }
        const data: SavedNote[] = await res.json();
        setNotes(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unexpected error";
        setError(message);
      } finally {
        setLoading(false);
      }
    };
    fetchNotes();
  }, [token, refreshKey]);

  const selectedNote = useMemo(() => {
    if (!note?.id) return null;
    return notes.find((entry) => entry.id === note.id) || null;
  }, [note, notes]);

  const formatDate = (iso?: string) => {
    if (!iso) return "Unknown";
    const d = new Date(iso);
    return d.toLocaleString();
  };

  const buildMarkdown = (currentNote: Note) => {
    const lines: string[] = [];
    if (currentNote.lecture_title) {
      lines.push(`# ${currentNote.lecture_title}`);
    }
    if (currentNote.keywords?.length) {
      lines.push("");
      lines.push(`**Keywords:** ${currentNote.keywords.join(", ")}`);
    }
    currentNote.sections.forEach((section) => {
      lines.push("");
      lines.push(`## ${section.title}`);
      if (section.key_points?.length) {
        lines.push("");
        section.key_points.forEach((point) => {
          lines.push(`- ${point}`);
        });
      }
      if (section.examples?.length) {
        lines.push("");
        lines.push("**Examples:**");
        section.examples.forEach((example) => {
          lines.push(`- ${example}`);
        });
      }
      if (section.summary) {
        lines.push("");
        lines.push(`**Summary:** ${section.summary}`);
      }
    });
    return lines.join("\n").trim();
  };

  const handleDownloadMarkdown = () => {
    if (!selectedNote) return;
    const markdown = buildMarkdown(selectedNote);
    const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    const title = selectedNote.lecture_title || "lecture-notes";
    const safeTitle = title.replace(/[<>:"/\\|?*]+/g, "").trim() || "lecture-notes";
    anchor.href = url;
    anchor.download = `${safeTitle}.md`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const handleDelete = async () => {
    if (!deleteTarget?.id) return;
    setDeleteLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/notes/${deleteTarget.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Failed to delete lecture.");
      }
      setNotes((prev) => prev.filter((entry) => entry.id !== deleteTarget.id));
      onNoteDeleted(deleteTarget.id);
      setDeleteTarget(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setError(message);
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <>
      <div className="card">
      <h3 className="section-title">Lecture Notes</h3>
      <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
        Browse previously saved lectures and review details.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(240px, 0.9fr) minmax(0, 1.3fr)",
          gap: 14,
        }}
      >
        <div
          style={{
            border: "1px solid #e3e7ee",
            borderRadius: 12,
            maxHeight: 520,
            overflow: "auto",
          }}
        >
          {loading ? (
            <div className="empty-state" style={{ padding: 20 }}>
              Loading lecture history...
            </div>
          ) : notes.length === 0 ? (
            <div className="empty-state" style={{ padding: 20 }}>
              No saved lectures yet.
            </div>
          ) : (
            notes.map((entry) => (
              <div
                key={entry.id}
                onClick={() => onSelectNote(entry)}
                style={{
                  padding: 12,
                  borderBottom: "1px solid #eef2fb",
                  cursor: "pointer",
                  background: note?.id === entry.id ? "#f5f7ff" : "transparent",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 8,
                    alignItems: "center",
                  }}
                >
                  <div style={{ fontWeight: 700, flex: 1, minWidth: 0 }}>
                    {entry.lecture_title || "Untitled Lecture"}
                  </div>
                  <button
                    className="button danger compact"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteTarget(entry);
                    }}
                  >
                    Delete
                  </button>
                </div>
                <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>
                  {formatDate(entry.created_at)}
                </div>
              </div>
            ))
          )}
        </div>

        <div
          style={{
            border: "1px solid #e3e7ee",
            borderRadius: 12,
            padding: 14,
            minHeight: 240,
            background: "#fbfcff",
          }}
        >
          {selectedNote ? (
            <>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                  gap: 12,
                  flexWrap: "wrap",
                }}
              >
                <div style={{ flex: "1 1 240px", minWidth: 0 }}>
                  <div className="muted" style={{ fontSize: 13, letterSpacing: 0.3 }}>
                    Lecture
                  </div>
                  <h3
                    className="section-title"
                    style={{ marginBottom: 8, wordBreak: "break-word" }}
                  >
                    {selectedNote.lecture_title || "Untitled Lecture"}
                  </h3>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {selectedNote.keywords?.map((kw) => (
                      <span key={kw} className="tag">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <button
                    className="button primary"
                    onClick={() => setStructuredOpen(true)}
                  >
                    Structured Notes
                  </button>
                  <button
                    className="button primary"
                    onClick={() => setTranscriptOpen(true)}
                  >
                    Transcript
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="empty-state" style={{ padding: 20 }}>
              Select a lecture from the list to view details.
            </div>
          )}
        </div>
      </div>

        {error && (
          <div style={{ marginTop: 12 }}>
            <span className="status-pill error">{error}</span>
          </div>
        )}
      </div>

      {deleteTarget && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div className="card modal-card" style={{ width: "min(420px, 92vw)" }}>
            <h3 className="section-title">Delete Lecture</h3>
            <p className="muted" style={{ marginTop: 0, marginBottom: 16 }}>
              Delete "{deleteTarget.lecture_title || "Untitled Lecture"}"? This will also remove its
              mind map.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="button secondary" onClick={() => setDeleteTarget(null)}>
                Cancel
              </button>
              <button className="button danger" onClick={handleDelete} disabled={deleteLoading}>
                {deleteLoading ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}

      {structuredOpen && selectedNote && (
        <div
          onClick={() => setStructuredOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div
            className="card modal-card"
            onClick={(event) => event.stopPropagation()}
            style={{ width: "min(760px, 92vw)", maxHeight: "80vh", overflow: "auto" }}
          >
            <h3 className="section-title">Structured Notes</h3>
            {selectedNote.sections?.length ? (
              selectedNote.sections.map((section, idx) => (
                <div key={`${section.title}-${idx}`} className="note-section">
                  <h4>{section.title}</h4>
                  {section.key_points?.length > 0 && (
                    <ul>
                      {section.key_points.map((point, index) => (
                        <li key={`${point}-${index}`}>{point}</li>
                      ))}
                    </ul>
                  )}
                  {section.summary && <div className="summary">{section.summary}</div>}
                </div>
              ))
            ) : (
              <div className="empty-state">No sections returned from the model.</div>
            )}
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
              <button className="button secondary" onClick={() => setStructuredOpen(false)}>
                Close
              </button>
              <button className="button primary" onClick={handleDownloadMarkdown}>
                下载
              </button>
            </div>
          </div>
        </div>
      )}

      {transcriptOpen && selectedNote && (
        <div
          onClick={() => setTranscriptOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
        >
          <div
            className="card modal-card"
            onClick={(event) => event.stopPropagation()}
            style={{ width: "min(760px, 92vw)", maxHeight: "80vh", overflow: "auto" }}
          >
            <h3 className="section-title">Transcript</h3>
            <div className="transcript-box" style={{ marginTop: 12 }}>
              {selectedNote.raw_transcript || "No transcript available."}
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
              <button className="button secondary" onClick={() => setTranscriptOpen(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
