type Props = {
  activeTab: "notes" | "mindmap" | "errors" | "dashboard" | "account";
  onTabChange: (tab: Props["activeTab"]) => void;
  showTabs?: boolean;
};

const tabs: { key: Props["activeTab"]; label: string }[] = [
  { key: "notes", label: "Lecture Notes" },
  { key: "mindmap", label: "Mind Map" },
  { key: "errors", label: "Error Book" },
  { key: "dashboard", label: "Dashboard" },
  { key: "account", label: "Account" },
];

export default function Header({ activeTab, onTabChange, showTabs = true }: Props) {
  return (
    <header className="top-nav">
      <div className="nav-left">AI Study Assistant</div>
      {showTabs && (
        <div className="nav-right">
          <div className="tabs">
            {tabs.map((tab) => (
              <div
                key={tab.key}
                className={`tab ${activeTab === tab.key ? "active" : ""}`}
                onClick={() => onTabChange(tab.key)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onTabChange(tab.key);
                }}
              >
                {tab.label}
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
