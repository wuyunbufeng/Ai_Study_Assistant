import { useEffect, useMemo, useState } from "react";
import Header from "./components/layout/Header";
import UploadCard from "./components/UploadCard";
import NotesView from "./components/NotesView";
import MindMapView from "./components/MindMapView";
import ErrorBookView from "./components/ErrorBookView";
import DashboardView from "./components/DashboardView";
import AuthView from "./components/AuthView";
import AccountView from "./components/AccountView";
import { Note } from "./types";
import { User } from "./types/auth";

const API_BASE = "http://127.0.0.1:8000";
const TOKEN_KEY = "auth_token";

type TabKey = "notes" | "mindmap" | "errors" | "dashboard" | "account";

function App() {
  const [activeTab, setActiveTab] = useState<TabKey>("notes");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [note, setNote] = useState<Note | null>(null);
  const [noteAudioUrl, setNoteAudioUrl] = useState<string | null>(null);
  const [noteAudioLabel, setNoteAudioLabel] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("Idle");
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [dataVersion, setDataVersion] = useState(0);

  const fileInfo = useMemo(() => {
    if (!selectedFile) return null;
    const sizeMB = (selectedFile.size / (1024 * 1024)).toFixed(2);
    return `${selectedFile.name} · ${sizeMB} MB`;
  }, [selectedFile]);

  const fetchMe = async (authToken: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/auth/me`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) {
        throw new Error("Session expired");
      }
      const user: User = await res.json();
      setCurrentUser(user);
    } catch {
      localStorage.removeItem(TOKEN_KEY);
      setToken(null);
      setCurrentUser(null);
    }
  };

  useEffect(() => {
    const stored = localStorage.getItem(TOKEN_KEY);
    if (!stored) {
      setAuthLoading(false);
      return;
    }
    setToken(stored);
    fetchMe(stored).finally(() => setAuthLoading(false));
  }, []);

  const handleAuthSuccess = async (authToken: string) => {
    localStorage.setItem(TOKEN_KEY, authToken);
    setToken(authToken);
    await fetchMe(authToken);
  };

  const applyNoteAudioPreview = (selectedNote: Note | null) => {
    if (!selectedNote?.audio_path) {
      setNoteAudioUrl(null);
      setNoteAudioLabel(null);
      return;
    }
    const safePath = selectedNote.audio_path.replace(/^\/+/, "");
    setNoteAudioUrl(`${API_BASE}/static/${safePath}`);
    setNoteAudioLabel(
      selectedNote.lecture_title ? `Saved audio: ${selectedNote.lecture_title}` : "Saved audio"
    );
  };

  const handleNoteSelect = (selectedNote: Note | null) => {
    setNote(selectedNote);
    applyNoteAudioPreview(selectedNote);
    if (selectedNote?.audio_path) {
      setSelectedFile(null);
      setStatus((prev) => (prev === "File selected" ? "Idle" : prev));
    }
  };

  const handleNoteDeleted = (noteId: number) => {
    setNote((current) => (current?.id === noteId ? null : current));
    if (note?.id === noteId) {
      setNoteAudioUrl(null);
      setNoteAudioLabel(null);
    }
    setDataVersion((prev) => prev + 1);
  };

  const handleUserUpdate = (user: User, accessToken?: string) => {
    setCurrentUser(user);
    if (accessToken) {
      localStorage.setItem(TOKEN_KEY, accessToken);
      setToken(accessToken);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setCurrentUser(null);
    setActiveTab("notes");
    setSelectedFile(null);
    setNote(null);
    setNoteAudioUrl(null);
    setNoteAudioLabel(null);
    setStatus("Idle");
    setError(null);
  };

  const handleFileSelect = (file: File | null) => {
    setSelectedFile(file);
    setNoteAudioUrl(null);
    setNoteAudioLabel(null);
    setError(null);
    setStatus(file ? "File selected" : "Idle");
  };

  const handleGenerate = async () => {
    if (!selectedFile) {
      setError("Please select an audio file first.");
      return;
    }

    setLoading(true);
    setStatus("Uploading and generating...");
    setError(null);

    try {
      const formData = new FormData();
      formData.append("file", selectedFile);

      const response = await fetch(`${API_BASE}/api/audio/upload`, {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
        body: formData,
      });

      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Failed to generate notes");
      }

      const data: Note = await response.json();
      let savedNote = data;

      try {
        const saveResponse = await fetch(`${API_BASE}/api/notes/save`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify(data),
        });

        if (!saveResponse.ok) {
          const message = await saveResponse.text();
          throw new Error(message || "Failed to save note");
        }

        savedNote = await saveResponse.json();
        setStatus("Generation completed");
        setDataVersion((prev) => prev + 1);
      } catch (saveErr) {
        const message =
          saveErr instanceof Error ? saveErr.message : "Failed to save note";
        setError(message);
        setStatus("Generated (not saved)");
      }

      setNote(savedNote);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setError(message);
      setStatus("Failed to generate");
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <>
        <Header activeTab="notes" onTabChange={() => {}} showTabs={false} />
        <div className="app-shell" style={{ maxWidth: 520 }}>
          <div className="card">
            <div className="muted">Checking session...</div>
          </div>
        </div>
      </>
    );
  }

  if (!token || !currentUser) {
    return (
      <>
        <Header activeTab="notes" onTabChange={() => {}} showTabs={false} />
        <AuthView onAuthSuccess={handleAuthSuccess} />
      </>
    );
  }

  return (
    <>
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      <div className="app-shell">
        {activeTab === "notes" && (
          <div className="grid two-column">
            <UploadCard
              selectedFile={selectedFile}
              selectedFileInfo={fileInfo}
              previewAudioUrl={noteAudioUrl}
              previewAudioLabel={noteAudioLabel}
              onFileSelect={handleFileSelect}
              onGenerate={handleGenerate}
              onClearFile={() => handleFileSelect(null)}
              loading={loading}
              status={status}
              error={error}
            />
            <NotesView
              note={note}
              token={token}
              refreshKey={dataVersion}
              onSelectNote={handleNoteSelect}
              onNoteDeleted={handleNoteDeleted}
            />
          </div>
        )}
        {activeTab === "mindmap" && (
          <MindMapView
            note={note}
            token={token}
            refreshKey={dataVersion}
            onNoteDeleted={handleNoteDeleted}
          />
        )}
        {activeTab === "errors" && <ErrorBookView token={token} />}
        {activeTab === "dashboard" && <DashboardView token={token} />}
        {activeTab === "account" && (
          <AccountView
            user={currentUser}
            token={token}
            onUserUpdate={handleUserUpdate}
            onLogout={handleLogout}
          />
        )}
      </div>
    </>
  );
}

export default App;
