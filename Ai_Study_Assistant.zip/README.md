# AI Lecture Note Assistant

Backend skeleton for an AI-powered lecture note assistant. Core flow: students upload classroom audio, the service transcribes it (Whisper) and summarizes into structured notes via LLM. Future modules will cover mind maps, wrong-question notebook, and study dashboards.

conda activate ai-note-assistant

## Project Structure
```
AI_Lecture_Note_Assistant/
  backend/
    app/
      __init__.py
      main.py
      core/
        __init__.py
        config.py
        db.py
      models/
        notes.py
        mindmap.py
        errors.py
      services/
        asr.py
        llm.py
        notes.py
      routers/
        health.py
        audio.py
        notes.py
        mindmap.py
        errors.py
  frontend/
  data/
  .env.example
  requirements.txt
  README.md
```

## Quickstart
1) Create and activate a virtual environment (e.g., `python -m venv .venv && .\.venv\Scripts\activate` on Windows).
2) Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3) Configure environment:
   ```bash
   cp .env.example .env  # then edit .env to add OPENAI_API_KEY, etc.
   ```
4) Run the server:
   ```bash
   uvicorn backend.app.main:app --reload
   ```
5) Run the frontend:
   ```bash
   cd frontend
   npm install
   npm run dev -- --host 127.0.0.1 --port 5174
   ```

Health check: `GET http://localhost:8000/health`

Audio upload + note generation: `POST http://localhost:8000/api/audio/upload` with form field `file` containing an audio file. Returns JSON `Note` (draft).
Persist note: `POST http://localhost:8000/api/notes/save`.

## API Sketch (current)
- `GET /health` — basic health probe.
- `POST /api/auth/register` — register a new user.
- `POST /api/auth/login` — login and receive JWT token.
- `GET /api/auth/me` — get current user (requires auth).
- `POST /api/audio/upload` — upload audio, returns structured note JSON (draft).
- `POST /api/notes/save` — save a lecture note.
- `GET /api/notes` — list saved notes.
- `GET /api/notes/{note_id}` — get a saved note.
- `POST /api/mindmap/from_note` — generate + save a mind map from a note id.
- `GET /api/mindmap` — list saved mind maps.
- `GET /api/mindmap/{mindmap_id}` — get a saved mind map.
- `POST /api/errors/ocr` — upload image and run OCR.
- `POST /api/errors/save` — save an error-book entry.
- `GET /api/errors` — list saved error-book entries.
- `GET /api/errors/{question_id}` — get one entry.

Note: all `/api/*` endpoints except `/api/auth/*` require an `Authorization: Bearer <token>` header.

### Frontend Placeholder
- Frontend calls the above endpoints to upload audio, display generated notes, and render mind maps and wrong-question notebooks.
- Notes JSON is already front-end friendly: `lecture_title`, `keywords`, `sections[]` with `title`, `key_points`, `examples`, `summary`, plus optional `raw_transcript`.

## Development Notes
- ASR/LLM calls are wired for OpenAI (`openai` SDK). Without `OPENAI_API_KEY`, the services fall back to mock data so local flow remains testable.
- Temp uploads are stored under `./tmp/` and cleaned after processing.
- Tests: not configured in this repo.

## 使用说明(按顺序执行)
conda create -n ai-note-assistant python=3.10
conda activate ai-note-assistant
pip install -r requirements.txt
双击start_all.bat

cmd:
conda activate ai-note-assistant
uvicorn backend.app.main:app --reload --port 8000

powershell:
curl -X POST "http://127.0.0.1:8000/api/audio/upload" -F "file=@../data/audio/T2.mp3;type=audio/mpeg"
